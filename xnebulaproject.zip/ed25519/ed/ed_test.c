#include <stdio.h>
#include <stdint.h>
#include <string.h>
int xn_ed_verify(const uint8_t *sig, const uint8_t *pk, const uint8_t *digest);
static int hx(char c) { return c >= 'a' ? c - 'a' + 10 : c - '0'; }
static void unhex(const char *s, uint8_t *o, int n) {
    for (int i = 0; i < n; i++) o[i] = (uint8_t)((hx(s[2 * i]) << 4) | hx(s[2 * i + 1]));
}
int main(void) {
    static char line[1024];
    while (fgets(line, sizeof line, stdin)) {
        char *tok[4];
        int n = 0;
        for (char *t = strtok(line, " \n"); t && n < 4; t = strtok(NULL, " \n")) tok[n++] = t;
        if (n < 3) continue;
        uint8_t sig[64], pk[32], dg[64];
        unhex(tok[0], sig, 64);
        unhex(tok[1], pk, 32);
        unhex(tok[2], dg, 64);
        printf("%d\n", xn_ed_verify(sig, pk, dg));
    }
    return 0;
}
