import os, random, subprocess, sys
import nacl.signing
L = 2**252 + 27742317777372353535851937790883648493
random.seed(int(os.environ.get("ED_SEED", "3")))
runner = sys.argv[1:]

def sodium_ok(sig, pk, dg):
    try:
        nacl.signing.VerifyKey(pk).verify(dg, sig)
        return 1
    except Exception:
        return 0

cases = []
for _ in range(50):
    sk = nacl.signing.SigningKey.generate()
    pk = bytes(sk.verify_key)
    dg = os.urandom(64)
    sig = sk.sign(dg).signature
    cases.append((sig, pk, dg))
    s2 = bytearray(sig); s2[random.randrange(64)] ^= 1 << random.randrange(8); cases.append((bytes(s2), pk, dg))
    d2 = bytearray(dg); d2[random.randrange(64)] ^= 1 << random.randrange(8); cases.append((sig, pk, bytes(d2)))
    p2 = bytearray(pk); p2[random.randrange(32)] ^= 1 << random.randrange(8); cases.append((sig, bytes(p2), dg))
    s_int = int.from_bytes(sig[32:], "little")
    if s_int + L < 2**256:
        cases.append((sig[:32] + (s_int + L).to_bytes(32, "little"), pk, dg))
    cases.append((sig[:32] + os.urandom(32), pk, dg))
    other = nacl.signing.SigningKey.generate()
    cases.append((sig, bytes(other.verify_key), dg))
lines = ["%s %s %s" % (s.hex(), p.hex(), d.hex()) for s, p, d in cases]
out = subprocess.run(runner, input="\n".join(lines) + "\n", capture_output=True, text=True, check=True).stdout.split()
good = bad = 0
mism = 0
for (s, p, d), got in zip(cases, out):
    exp = sodium_ok(s, p, d)
    if int(got) == exp:
        good += 1
    else:
        mism += 1
        if mism <= 3:
            print("MISMATCH got", got, "libsodium", exp, s.hex()[:32])
print("cases:", len(cases), "agree:", good, "mismatch:", mism)
print("accepted by libsodium:", sum(sodium_ok(*c) for c in cases))
