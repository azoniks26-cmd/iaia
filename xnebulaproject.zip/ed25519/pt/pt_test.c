#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
void xn_pt_add(uint64_t *o, const uint64_t *p, const uint64_t *q);
void xn_pt_dbl(uint64_t *o, const uint64_t *p);
void xn_pt_scalar(uint64_t *o, const uint64_t *k, const uint64_t *p);
int xn_pt_decompress(uint64_t *o, const uint64_t *y, uint64_t sign);

static void parse(const char *s, uint64_t *l) {
    for (int i = 0; i < 4; i++) {
        uint64_t v = 0;
        const char *p = s + 48 - 16 * i;
        for (int k = 0; k < 16; k++) {
            char c = p[k];
            uint64_t d = (c >= 'a') ? (uint64_t)(c - 'a' + 10) : (uint64_t)(c - '0');
            v = (v << 4) | d;
        }
        l[i] = v;
    }
}

static void emit(const uint64_t *l) {
    for (int f = 0; f < 4; f++) {
        if (f) putchar(' ');
        for (int k = 3; k >= 0; k--) printf("%016llx", (unsigned long long)l[4 * f + k]);
    }
    printf("\n");
}

int main(void) {
    static char line[8192];
    while (fgets(line, sizeof line, stdin)) {
        char *tok[32];
        int n = 0;
        for (char *t = strtok(line, " \n"); t && n < 32; t = strtok(NULL, " \n")) tok[n++] = t;
        if (!n) continue;
        uint64_t r[16];
        memset(r, 0, sizeof r);
        if (!strcmp(tok[0], "pa")) {
            uint64_t p[16], q[16];
            for (int f = 0; f < 4; f++) { parse(tok[1 + f], p + 4 * f); parse(tok[5 + f], q + 4 * f); }
            xn_pt_add(r, p, q);
            emit(r);
        } else if (!strcmp(tok[0], "pd")) {
            uint64_t p[16];
            for (int f = 0; f < 4; f++) parse(tok[1 + f], p + 4 * f);
            xn_pt_dbl(r, p);
            emit(r);
        } else if (!strcmp(tok[0], "sm")) {
            uint64_t k[4], p[16];
            parse(tok[1], k);
            for (int f = 0; f < 4; f++) parse(tok[2 + f], p + 4 * f);
            xn_pt_scalar(r, k, p);
            emit(r);
        } else if (!strcmp(tok[0], "dec")) {
            uint64_t y[4];
            parse(tok[1], y);
            uint64_t sign = strtoull(tok[2], NULL, 10);
            if (xn_pt_decompress(r, y, sign)) puts("INVALID");
            else emit(r);
        }
    }
    return 0;
}
