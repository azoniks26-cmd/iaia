import os, random, subprocess, sys
p = 2**255 - 19
L = 2**252 + 27742317777372353535851937790883648493
d = (-121665 * pow(121666, p - 2, p)) % p
I = pow(2, (p - 1) // 4, p)
inv = lambda a: pow(a, p - 2, p)
random.seed(int(os.environ.get("PT_SEED", "11")))

def aadd(P, Q):
    x1, y1 = P
    x2, y2 = Q
    t = d * x1 * x2 * y1 * y2 % p
    return ((x1 * y2 + y1 * x2) * inv(1 + t) % p, (y1 * y2 + x1 * x2) * inv(1 - t) % p)

def smul(k, P):
    R = (0, 1)
    for i in range(k.bit_length() - 1, -1, -1):
        R = aadd(R, R)
        if (k >> i) & 1:
            R = aadd(R, P)
    return R

def decomp(y, sign):
    u = (y * y - 1) % p
    v = (d * y * y + 1) % p
    x2 = u * inv(v) % p
    if x2 == 0:
        return None if sign else (0, y)
    x = pow(x2, (p + 3) // 8, p)
    if x * x % p != x2:
        x = x * I % p
    if x * x % p != x2:
        return None
    if (x & 1) != sign:
        x = (p - x) % p
    return (x, y)

By = 4 * inv(5) % p
Bx = decomp(By, 0)[0]
B = (Bx, By)

def enc(P):
    x, y = P
    return (y | ((x & 1) << 255)).to_bytes(32, "little")

def f(v):
    return "%064x" % v

def ext(P, z):
    x, y = P
    return [x * z % p, y * z % p, z, x * y * z % p]

def run(runner, lines):
    out = subprocess.run(runner, input="\n".join(lines) + "\n", capture_output=True, text=True, check=True).stdout.split("\n")
    return out

def to_affine(fields):
    X, Y, Z, T = [int(s, 16) for s in fields]
    if Z % p == 0:
        return None
    iz = inv(Z)
    assert T * Z % p == X * Y % p, "T inconsistent"
    return (X * iz % p, Y * iz % p)

def rnd_point():
    return smul(random.getrandbits(64) | 1, B)

runner = sys.argv[1:]
cases = []
for _ in range(60):
    P = rnd_point(); Q = rnd_point()
    zp = random.randrange(1, p); zq = random.randrange(1, p)
    cases.append(("pa", " ".join(f(v) for v in ext(P, zp) + ext(Q, zq)), aadd(P, Q)))
ident = (0, 1)
P = rnd_point()
cases.append(("pa", " ".join(f(v) for v in ext(P, 5) + ext(ident, 7)), P))
cases.append(("pa", " ".join(f(v) for v in ext(P, 3) + ext((p - P[0], P[1]), 9)), ident))
cases.append(("pa", " ".join(f(v) for v in ext(P, 3) + ext(P, 11)), aadd(P, P)))
cases.append(("pa", " ".join(f(v) for v in ext(B, 1) + ext(B, 1)), aadd(B, B)))
for _ in range(60):
    P = rnd_point()
    cases.append(("pd", " ".join(f(v) for v in ext(P, random.randrange(1, p))), aadd(P, P)))
cases.append(("pd", " ".join(f(v) for v in ext(ident, 1)), ident))
for _ in range(40):
    k = random.getrandbits(256)
    P = rnd_point()
    cases.append(("sm", f(k) + " " + " ".join(f(v) for v in ext(P, random.randrange(1, p))), smul(k, P)))
for k in [0, 1, 2, L - 1, L, 2**256 - 1]:
    cases.append(("sm", f(k) + " " + " ".join(f(v) for v in ext(B, 1)), smul(k, B)))
for _ in range(40):
    P = rnd_point()
    sign = P[0] & 1
    cases.append(("dec", "%s %d" % (f(P[1]), sign), P))
    cases.append(("dec", "%s %d" % (f(P[1]), 1 - sign), decomp(P[1], 1 - sign)))
cases.append(("dec", "%s 0" % f(1), (0, 1)))
cases.append(("dec", "%s 1" % f(1), None))
for _ in range(60):
    y = random.randrange(p)
    sign = random.getrandbits(1)
    cases.append(("dec", "%s %d" % (f(y), sign), decomp(y, sign)))
lines = []
for op, args, _ in cases:
    lines.append("%s %s" % (op, args))
out = run(runner, lines)
bad = {}
for (op, args, exp), got in zip(cases, out):
    if op == "dec":
        if exp is None:
            ok = got == "INVALID"
        else:
            ok = got != "INVALID" and to_affine(got.split()) == exp
    else:
        if got == "INVALID":
            ok = False
        else:
            aff = to_affine(got.split())
            ok = aff == exp
    if not ok:
        bad[op] = bad.get(op, 0) + 1
        if bad[op] <= 2:
            print("MISMATCH", op, args[:80], "got", got[:80], "exp", exp)
print("cases:", len(cases), "mismatches:", bad or "none")
if "libsodium" in os.environ.get("PT_CHECK", "libsodium"):
    try:
        import nacl.bindings as nb
        ok = 0
        ks = [random.randrange(1, L) for _ in range(30)]
        lines2 = ["sm %s %s" % (f(k), " ".join(f(v) for v in ext(B, 1))) for k in ks]
        outs = run(runner, lines2)
        for k, got in zip(ks, outs):
            sodium = nb.crypto_scalarmult_ed25519_base_noclamp(k.to_bytes(32, "little"))
            mine = enc(to_affine(got.split()))
            if sodium == mine:
                ok += 1
        print("libsodium base-mult agreement:", ok, "/", len(ks))
    except ImportError:
        print("pynacl not available, libsodium check skipped")
