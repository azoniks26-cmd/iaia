import random, subprocess, sys
p = 2**255 - 19
runner = sys.argv[1:]
random.seed(int(__import__("os").environ.get("FE_SEED", "7")))
cases = []
def add(op, a, b, exp):
    cases.append((op, a, b, exp))
big_edge = [0, 1, 2, 19, 38, p - 1, p, p + 1, p + 18, 2**255, 2**256 - 1, 2**256 - 38, 2**256 - 19]
for a in big_edge:
    for b in big_edge:
        add("m", a, b, (a * b) % p)
for _ in range(4000):
    a = random.getrandbits(256); b = random.getrandbits(256)
    add("m", a, b, (a * b) % p)
canon = [0, 1, 2, 19, p - 1, p - 2, (p + 1) // 2, 2**254]
for a in canon:
    for b in canon:
        add("a", a, b, (a + b) % p)
        add("s", a, b, (a - b) % p)
for _ in range(3000):
    a = random.randrange(p); b = random.randrange(p)
    add("a", a, b, (a + b) % p)
    add("s", a, b, (a - b) % p)
e_vals = [0, 1, 2, 3, 5, p - 2, (p + 3) // 8, (p - 1) // 4, 2**256 - 1]
for _ in range(60):
    e_vals.append(random.getrandbits(256))
for a in [0, 1, 2, p - 1, 19] + [random.randrange(p) for _ in range(40)]:
    for e in e_vals:
        add("p", a, e, pow(a, e, p))
inp = "".join("%s %064x %064x\n" % (op, a, b) for op, a, b, _ in cases)
out = subprocess.run(runner, input=inp, capture_output=True, text=True, check=True).stdout.split("\n")
bad = {}
for (op, a, b, exp), got in zip(cases, out):
    if got != "%064x" % exp:
        bad[op] = bad.get(op, 0) + 1
        if bad[op] <= 3:
            print("MISMATCH", op, hex(a), hex(b), "got", got, "exp", "%064x" % exp)
print("cases:", len(cases), "mismatches by op:", bad or "none")
