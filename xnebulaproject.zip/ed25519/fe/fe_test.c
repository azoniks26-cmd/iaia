#include <stdio.h>
#include <stdint.h>
#include <string.h>
void xn_fe_mul(uint64_t *o, const uint64_t *a, const uint64_t *b);
void xn_fe_add(uint64_t *o, const uint64_t *a, const uint64_t *b);
void xn_fe_sub(uint64_t *o, const uint64_t *a, const uint64_t *b);
void xn_fe_pow(uint64_t *o, const uint64_t *a, const uint64_t *e);

static void parse(const char *s, uint64_t *l) {
    for (int i = 0; i < 4; i++) {
        uint64_t v = 0;
        const char *p = s + 48 - 16 * i;
        for (int k = 0; k < 16; k++) {
            char c = p[k];
            uint64_t d = (c >= 'a') ? (uint64_t)(c - 'a' + 10) : (uint64_t)(c - '0');
            v = (v << 4) | d;
        }
        l[i] = v;
    }
}

static void emit(const uint64_t *l) {
    for (int i = 3; i >= 0; i--) printf("%016llx", (unsigned long long)l[i]);
    printf("\n");
}

int main(void) {
    char op[4], a[70], b[70];
    while (scanf("%3s %68s %68s", op, a, b) == 3) {
        uint64_t x[4], y[4], r[4];
        parse(a, x);
        parse(b, y);
        if (op[0] == 'm') xn_fe_mul(r, x, y);
        else if (op[0] == 'a') xn_fe_add(r, x, y);
        else if (op[0] == 's') xn_fe_sub(r, x, y);
        else xn_fe_pow(r, x, y);
        emit(r);
    }
    return 0;
}
