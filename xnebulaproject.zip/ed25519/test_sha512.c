#include <stdio.h>
#include <stdint.h>
void xn_sha512(const uint8_t *m, uint64_t n, uint8_t *out);
static uint8_t buf[4096];
int main(void) {
    for (uint64_t i = 0; i < sizeof buf; i++) buf[i] = (uint8_t)(i * 7 + 3);
    for (uint64_t n = 0; n <= 1200; n++) {
        uint8_t out[64];
        xn_sha512(buf, n, out);
        for (int i = 0; i < 64; i++) printf("%02x", out[i]);
        printf("\n");
    }
    return 0;
}
