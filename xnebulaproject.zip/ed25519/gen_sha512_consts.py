def primes(n):
    ps = []
    c = 2
    while len(ps) < n:
        if all(c % p for p in ps if p * p <= c):
            ps.append(c)
        c += 1
    return ps

def iroot(x, k):
    lo, hi = 0, 1 << ((x.bit_length() // k) + 2)
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if mid ** k <= x:
            lo = mid
        else:
            hi = mid - 1
    return lo

M = (1 << 64) - 1
ps = primes(80)
K = [iroot(p << 192, 3) & M for p in ps]
IV = [iroot(p << 128, 2) & M for p in ps[:8]]

with open("sha512_k.inc", "w") as f:
    f.write(".balign 8\n.Lxn_sha512_k:\n")
    for i in range(0, 80, 2):
        f.write(".quad 0x%016x, 0x%016x\n" % (K[i], K[i + 1]))
    f.write(".Lxn_sha512_iv:\n")
    for v in IV:
        f.write(".quad 0x%016x\n" % v)
print("K[0]=%016x K[79]=%016x IV[0]=%016x" % (K[0], K[79], IV[0]))
