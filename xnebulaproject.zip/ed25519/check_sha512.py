import hashlib, sys
lines = sys.stdin.read().split("\n")
bad = 0
for n, got in enumerate(l for l in lines if l):
    exp = hashlib.sha512(bytes((i * 7 + 3) & 0xff for i in range(n))).hexdigest()
    if got != exp:
        bad += 1
        if bad < 5:
            print("MISMATCH len", n)
print("lengths checked:", len([l for l in lines if l]), "mismatches:", bad)
