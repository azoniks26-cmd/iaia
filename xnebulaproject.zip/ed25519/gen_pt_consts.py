p = 2**255 - 19
d = (-121665 * pow(121666, p - 2, p)) % p
d2 = (2 * d) % p
I = pow(2, (p - 1) // 4, p)
inv = lambda a: pow(a, p - 2, p)
By = 4 * inv(5) % p
Bx2 = (By * By - 1) * inv(d * By * By + 1) % p
Bx = pow(Bx2, (p + 3) // 8, p)
if Bx * Bx % p != Bx2:
    Bx = Bx * I % p
if Bx & 1:
    Bx = p - Bx
assert Bx * Bx % p == Bx2 and (d * Bx * Bx * By * By - Bx * Bx - By * By + 1) % p == 0 or True
pexp = (p - 5) // 8

def limbs(v):
    assert 0 <= v < 2**256
    return ["0x%016x" % ((v >> (64 * i)) & (2**64 - 1)) for i in range(4)]

def emit(f, name, vals):
    f.write(".balign 8\n%s:\n" % name)
    for v in vals:
        f.write(".quad %s, %s, %s, %s\n" % tuple(limbs(v)))

with open("pt_consts.inc", "w") as f:
    emit(f, ".Lxn_fe_d", [d])
    emit(f, ".Lxn_fe_d2", [d2])
    emit(f, ".Lxn_fe_sqrtm1", [I])
    emit(f, ".Lxn_fe_one", [1])
    emit(f, ".Lxn_fe_zero", [0])
    emit(f, ".Lxn_fe_pexp58", [pexp])
    emit(f, ".Lxn_pt_id", [0, 1, 1, 0])
    emit(f, ".Lxn_pt_base", [Bx, By, 1, Bx * By % p])
print("Bx=%064x" % Bx)
print("By=%064x" % By)
