#include <cstdio>
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <vector>
#include <string>
#include <algorithm>
#include <limits>
#include <map>
#include <elf.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sodium.h>

asm(R"asm(
.text
.macro QR a, b, c, d
mov \b(%rsp), %eax
add %eax, \a(%rsp)
mov \a(%rsp), %eax
xor %eax, \d(%rsp)
mov \d(%rsp), %eax
rol $16, %eax
mov %eax, \d(%rsp)
mov \d(%rsp), %eax
add %eax, \c(%rsp)
mov \c(%rsp), %eax
xor %eax, \b(%rsp)
mov \b(%rsp), %eax
rol $12, %eax
mov %eax, \b(%rsp)
mov \b(%rsp), %eax
add %eax, \a(%rsp)
mov \a(%rsp), %eax
xor %eax, \d(%rsp)
mov \d(%rsp), %eax
rol $8, %eax
mov %eax, \d(%rsp)
mov \d(%rsp), %eax
add %eax, \c(%rsp)
mov \c(%rsp), %eax
xor %eax, \b(%rsp)
mov \b(%rsp), %eax
rol $7, %eax
mov %eax, \b(%rsp)
.endm
.globl xn_stub_start
.type xn_stub_start,@function
xn_stub_start:
call .Lxn_self
.Lxn_self:
pop %rax
sub $5, %rax
push %rbp
push %rbx
push %r12
push %r13
push %r14
push %r15
sub $1032, %rsp
lea xn_cfg_start(%rip), %rbx
movabs $0x584e4542554c4158, %r9
cmp %r9, 0(%rbx)
je .Lxn_magic_ok
lea .Lmsg_bad(%rip), %rsi
mov $(.Lmsg_bad_end - .Lmsg_bad), %edx
jmp .Lxn_die
.Lxn_magic_ok:
mov 8(%rbx), %r9
mov %rax, %r10
sub %r9, %r10
mov %r10, 0(%rsp)
mov 16(%rbx), %r9
mov %r9, 8(%rsp)
mov 24(%rbx), %r9
mov %r9, 16(%rsp)
lea 96(%rbx), %r9
mov %r9, 24(%rsp)
mov 24(%rbx), %rsi
imul $80, %rsi, %rsi
add $96, %rsi
mov %rbx, %rdi
lea 640(%rsp), %rdx
call xn_sha512
mov 24(%rbx), %rax
imul $80, %rax, %rax
lea 96(%rbx,%rax,1), %rdi
lea 64(%rbx), %rsi
lea 640(%rsp), %rdx
call xn_ed_verify
test %eax, %eax
jz .Lxn_err_sig
mov $4, %edi
xor %esi, %esi
mov $157, %eax
syscall
call .Lxn_tracer_check
mov $9, %eax
xor %edi, %edi
mov $16384, %esi
mov $3, %edx
mov $0x22, %r10d
mov $-1, %r8
xor %r9d, %r9d
syscall
test %rax, %rax
js .Lxn_mon_fail
mov %rax, %r12
mov %rax, 320(%rsp)
mov 0(%rsp), %r9
mov %r9, 0(%rax)
lea 96(%rbx), %r9
mov %r9, 8(%rax)
mov 24(%rbx), %r9
mov %r9, 16(%rax)
movq $0, 24(%rax)
lea 16384(%rax), %rsi
mov $0x50f00, %edi
xor %edx, %edx
xor %r10d, %r10d
xor %r8d, %r8d
mov $56, %eax
syscall
test %rax, %rax
js .Lxn_mon_fail
jz .Lxn_monitor
.Lxn_dbg_done:
mov 0(%rsp), %rdi
add 8(%rbx), %rdi
mov $(xn_code_end - xn_stub_start), %esi
lea 704(%rsp), %rdx
call xn_sha512
.set xn_i, 0
.rept 4
mov 32+8*xn_i(%rbx), %r11
xor 704+8*xn_i(%rsp), %r11
mov %r11, 32+8*xn_i(%rsp)
.set xn_i, xn_i+1
.endr
.Lxn_range_loop:
cmpq $0, 16(%rsp)
je .Lxn_ranges_done
decq 16(%rsp)
mov 24(%rsp), %rsi
mov %rsi, 336(%rsp)
mov 0(%rsi), %r9
mov 8(%rsi), %r10
mov 16(%rsi), %r11
add $80, %rsi
mov %rsi, 24(%rsp)
mov %r9, 256(%rsp)
mov %r11, 280(%rsp)
mov %r10, %r11
shr $56, %r11
mov %r11, 272(%rsp)
shl $8, %r10
shr $8, %r10
mov %r10, 264(%rsp)
test %r10, %r10
jz .Lxn_range_loop
mov 0(%rsp), %r8
add %r8, %r9
mov %r9, 288(%rsp)
mov %r9, %rdi
and $-4096, %rdi
mov %r9, %rsi
add %r10, %rsi
add $4095, %rsi
and $-4096, %rsi
sub %rdi, %rsi
mov $3, %edx
mov $10, %eax
syscall
test %rax, %rax
jnz .Lxn_err_mprot
movl $0x61707865, 128(%rsp)
movl $0x3320646e, 132(%rsp)
movl $0x79622d32, 136(%rsp)
movl $0x6b206574, 140(%rsp)
.set xn_i, 0
.rept 4
mov 32+8*xn_i(%rsp), %r9
mov %r9, 144+8*xn_i(%rsp)
.set xn_i, xn_i+1
.endr
movl $0, 176(%rsp)
mov 256(%rsp), %r9
mov %r9d, 180(%rsp)
shr $32, %r9
mov %r9d, 184(%rsp)
mov 264(%rsp), %r9
mov %r9d, 188(%rsp)
mov 264(%rsp), %r9
mov %r9, 304(%rsp)
mov 288(%rsp), %r9
mov %r9, 296(%rsp)
movq $0, 312(%rsp)
.Lxn_block:
mov 312(%rsp), %r9
mov %r9d, 176(%rsp)
.set xn_i, 0
.rept 8
mov 128+8*xn_i(%rsp), %r9
mov %r9, 64+8*xn_i(%rsp)
.set xn_i, xn_i+1
.endr
mov $10, %r15d
.Lxn_round:
QR 64,80,96,112
QR 68,84,100,116
QR 72,88,104,120
QR 76,92,108,124
QR 64,84,104,124
QR 68,88,108,112
QR 72,92,96,116
QR 76,80,100,120
dec %r15d
jnz .Lxn_round
.set xn_i, 0
.rept 16
mov 128+4*xn_i(%rsp), %eax
add %eax, 64+4*xn_i(%rsp)
.set xn_i, xn_i+1
.endr
mov 304(%rsp), %r9
cmp $64, %r9
jbe .Lxn_nok
mov $64, %r9d
.Lxn_nok:
xor %ecx, %ecx
mov 296(%rsp), %rdi
.Lxn_xor:
cmp %r9, %rcx
jae .Lxn_xdone
movzbl 64(%rsp,%rcx,1), %eax
xor %al, (%rdi,%rcx,1)
inc %rcx
jmp .Lxn_xor
.Lxn_xdone:
add %r9, 296(%rsp)
sub %r9, 304(%rsp)
incq 312(%rsp)
cmpq $0, 304(%rsp)
jne .Lxn_block
mov 288(%rsp), %rdi
mov 264(%rsp), %rsi
lea 768(%rsp), %rdx
call xn_sha512
mov 336(%rsp), %rsi
add $16, %rsi
lea 768(%rsp), %rdi
mov $64, %ecx
repe cmpsb
jne .Lxn_err_integrity
mov 288(%rsp), %rdi
and $-4096, %rdi
mov 288(%rsp), %rsi
add 264(%rsp), %rsi
add $4095, %rsi
and $-4096, %rsi
sub %rdi, %rsi
mov 272(%rsp), %rdx
mov $10, %eax
syscall
test %rax, %rax
jnz .Lxn_err_mprot
jmp .Lxn_range_loop
.Lxn_ranges_done:
mov 320(%rsp), %r9
movq $1, 24(%r9)
mov 8(%rsp), %r9
test %r9, %r9
jz .Lxn_done
add 0(%rsp), %r9
call *%r9
.Lxn_done:
add $1032, %rsp
pop %r15
pop %r14
pop %r13
pop %r12
pop %rbx
pop %rbp
ret
.Lxn_err_mprot:
lea .Lmsg_mprot(%rip), %rsi
mov $(.Lmsg_mprot_end - .Lmsg_mprot), %edx
jmp .Lxn_die
.Lxn_err_sig:
lea .Lmsg_sig(%rip), %rsi
mov $(.Lmsg_sig_end - .Lmsg_sig), %edx
jmp .Lxn_die
.Lxn_err_integrity:
lea .Lmsg_integ(%rip), %rsi
mov $(.Lmsg_integ_end - .Lmsg_integ), %edx
jmp .Lxn_die
.Lxn_die:
mov $2, %edi
mov $1, %eax
syscall
mov $1, %edi
mov $231, %eax
syscall
.Lxn_tracer_check:
sub $2120, %rsp
lea .Lpath_task(%rip), %rsi
mov $-100, %rdi
mov $0x10000, %edx
mov $257, %eax
syscall
test %rax, %rax
js .Lxn_status_fail
mov %rax, 2048(%rsp)
.Lxn_tc_read:
mov 2048(%rsp), %rdi
mov %rsp, %rsi
mov $1024, %edx
mov $217, %eax
syscall
test %rax, %rax
js .Lxn_status_fail
jz .Lxn_tc_close
mov %rax, 2080(%rsp)
movq $0, 2072(%rsp)
.Lxn_tc_ent:
mov 2072(%rsp), %rax
cmp 2080(%rsp), %rax
jae .Lxn_tc_read
lea (%rsp,%rax,1), %r8
movzwl 16(%r8), %ecx
test %ecx, %ecx
jz .Lxn_status_fail
add %rcx, %rax
mov %rax, 2072(%rsp)
movzbl 19(%r8), %eax
cmp $48, %al
jb .Lxn_tc_ent
cmp $57, %al
ja .Lxn_tc_ent
mov 2048(%rsp), %rdi
lea 19(%r8), %rsi
mov $0x10000, %edx
mov $257, %eax
syscall
test %rax, %rax
js .Lxn_tc_ent
mov %rax, 2056(%rsp)
mov %rax, %rdi
lea .Lname_status(%rip), %rsi
xor %edx, %edx
mov $257, %eax
syscall
test %rax, %rax
js .Lxn_tc_close_tid
mov %rax, 2064(%rsp)
mov %rax, %rdi
lea 1024(%rsp), %rsi
mov $1023, %edx
xor %eax, %eax
syscall
mov %rax, 2088(%rsp)
mov 2064(%rsp), %rdi
mov $3, %eax
syscall
mov 2088(%rsp), %rdx
test %rdx, %rdx
jle .Lxn_tc_close_tid
lea 1024(%rsp), %rsi
add %rsi, %rdx
call .Lxn_scan_tracer
.Lxn_tc_close_tid:
mov 2056(%rsp), %rdi
mov $3, %eax
syscall
jmp .Lxn_tc_ent
.Lxn_tc_close:
mov 2048(%rsp), %rdi
mov $3, %eax
syscall
add $2120, %rsp
ret
.Lxn_scan_tracer:
lea .Lpat(%rip), %r8
.Lxn_sc_scan:
lea 10(%rsi), %r9
cmp %rdx, %r9
ja .Lxn_status_fail
xor %ecx, %ecx
.Lxn_sc_cmp:
cmp $10, %rcx
jae .Lxn_sc_found
movzbl (%rsi,%rcx,1), %eax
cmpb (%r8,%rcx,1), %al
jne .Lxn_sc_next
inc %rcx
jmp .Lxn_sc_cmp
.Lxn_sc_next:
inc %rsi
jmp .Lxn_sc_scan
.Lxn_sc_found:
add $10, %rsi
.Lxn_sc_ws:
cmp %rdx, %rsi
jae .Lxn_status_fail
movzbl (%rsi), %eax
cmp $32, %al
je .Lxn_sc_ws_next
cmp $9, %al
je .Lxn_sc_ws_next
cmp $48, %al
jne .Lxn_dbg_detected
ret
.Lxn_sc_ws_next:
inc %rsi
jmp .Lxn_sc_ws
.Lxn_status_fail:
lea .Lmsg_status(%rip), %rsi
mov $(.Lmsg_status_end - .Lmsg_status), %edx
jmp .Lxn_die
.Lxn_dbg_detected:
lea .Lmsg_dbg(%rip), %rsi
mov $(.Lmsg_dbg_end - .Lmsg_dbg), %edx
jmp .Lxn_die
.Lxn_mon_fail:
lea .Lmsg_mon(%rip), %rsi
mov $(.Lmsg_mon_end - .Lmsg_mon), %edx
jmp .Lxn_die
.Lxn_monitor:
sub $16, %rsp
movq $0, 0(%rsp)
movq $500000000, 8(%rsp)
.Lxn_mon_loop:
call .Lxn_tracer_check
cmpq $0, 24(%r12)
je .Lxn_mon_sleep
call .Lxn_integrity_scan
.Lxn_mon_sleep:
mov %rsp, %rdi
xor %esi, %esi
mov $35, %eax
syscall
jmp .Lxn_mon_loop
.Lxn_integrity_scan:
sub $64, %rsp
mov 8(%r12), %r13
mov 16(%r12), %r14
xor %r15d, %r15d
.Lxn_is_loop:
cmp %r14, %r15
jae .Lxn_is_done
imul $80, %r15, %rax
mov (%r13,%rax,1), %rdi
add (%r12), %rdi
mov 8(%r13,%rax,1), %rsi
shl $8, %rsi
shr $8, %rsi
mov %rsp, %rdx
call xn_sha512
imul $80, %r15, %rax
lea 16(%r13,%rax,1), %rsi
mov %rsp, %rdi
mov $64, %ecx
repe cmpsb
jne .Lxn_err_integrity
inc %r15
jmp .Lxn_is_loop
.Lxn_is_done:
add $64, %rsp
ret
.Lmsg_bad:
.ascii "XNebula: bad configuration\n"
.Lmsg_bad_end:
.Lmsg_dbg:
.ascii "XNebula: debugger detected\n"
.Lmsg_dbg_end:
.Lmsg_mprot:
.ascii "XNebula: mprotect refused (SELinux or W^X policy)\n"
.Lmsg_mprot_end:
.Lmsg_integ:
.ascii "XNebula: code integrity check failed\n"
.Lmsg_integ_end:
.Lmsg_sig:
.ascii "XNebula: signature verification failed\n"
.Lmsg_sig_end:
.Lmsg_status:
.ascii "XNebula: process state unavailable\n"
.Lmsg_status_end:
.Lmsg_mon:
.ascii "XNebula: monitor unavailable\n"
.Lmsg_mon_end:
.Lpath_task:
.asciz "/proc/self/task"
.Lname_status:
.asciz "status"
.Lpat:
.ascii "TracerPid:"
.text
.globl xn_sha512
.type xn_sha512,@function
.balign 16
xn_sha512:
push %rbp
push %rbx
push %r12
push %r13
push %r14
push %r15
sub $1088, %rsp
mov %rdi, 1040(%rsp)
mov %rsi, 1048(%rsp)
mov %rsi, 1056(%rsp)
mov %rdx, 1064(%rsp)
lea .Lxn_sha512_iv(%rip), %rax
mov 0(%rax), %rcx
mov %rcx, 0(%rsp)
mov 8(%rax), %rcx
mov %rcx, 8(%rsp)
mov 16(%rax), %rcx
mov %rcx, 16(%rsp)
mov 24(%rax), %rcx
mov %rcx, 24(%rsp)
mov 32(%rax), %rcx
mov %rcx, 32(%rsp)
mov 40(%rax), %rcx
mov %rcx, 40(%rsp)
mov 48(%rax), %rcx
mov %rcx, 48(%rsp)
mov 56(%rax), %rcx
mov %rcx, 56(%rsp)
.Lxn_sha512_full:
cmpq $128, 1048(%rsp)
jb .Lxn_sha512_tail
mov 1040(%rsp), %rsi
call .Lxn_sha512_block
addq $128, 1040(%rsp)
subq $128, 1048(%rsp)
jmp .Lxn_sha512_full
.Lxn_sha512_tail:
mov 1040(%rsp), %rsi
mov 1048(%rsp), %rcx
lea 704(%rsp), %rdi
xor %r8d, %r8d
.Lxn_sha512_cpy:
cmp %rcx, %r8
jae .Lxn_sha512_cpy_done
movzbl (%rsi,%r8), %eax
mov %al, (%rdi,%r8)
inc %r8
jmp .Lxn_sha512_cpy
.Lxn_sha512_cpy_done:
movb $0x80, (%rdi,%r8)
inc %r8
mov $128, %r9
cmpq $112, 1048(%rsp)
jb .Lxn_sha512_pad
mov $256, %r9
.Lxn_sha512_pad:
lea -16(%r9), %r10
.Lxn_sha512_zero:
cmp %r10, %r8
jae .Lxn_sha512_zero_done
movb $0, (%rdi,%r8)
inc %r8
jmp .Lxn_sha512_zero
.Lxn_sha512_zero_done:
mov 1056(%rsp), %rax
shl $3, %rax
bswap %rax
movq $0, -16(%rdi,%r9)
mov %rax, -8(%rdi,%r9)
mov %r9, 1072(%rsp)
lea 704(%rsp), %rsi
call .Lxn_sha512_block
cmpq $256, 1072(%rsp)
jne .Lxn_sha512_out
lea 832(%rsp), %rsi
call .Lxn_sha512_block
.Lxn_sha512_out:
mov 1064(%rsp), %rdi
mov 0(%rsp), %rax
bswap %rax
mov %rax, 0(%rdi)
mov 8(%rsp), %rax
bswap %rax
mov %rax, 8(%rdi)
mov 16(%rsp), %rax
bswap %rax
mov %rax, 16(%rdi)
mov 24(%rsp), %rax
bswap %rax
mov %rax, 24(%rdi)
mov 32(%rsp), %rax
bswap %rax
mov %rax, 32(%rdi)
mov 40(%rsp), %rax
bswap %rax
mov %rax, 40(%rdi)
mov 48(%rsp), %rax
bswap %rax
mov %rax, 48(%rdi)
mov 56(%rsp), %rax
bswap %rax
mov %rax, 56(%rdi)
add $1088, %rsp
pop %r15
pop %r14
pop %r13
pop %r12
pop %rbx
pop %rbp
ret

.set HB, 8
.set WB, 72
.set CNT, 968
.Lxn_sha512_block:
xor %ecx, %ecx
.Lxn_sha512_ld:
mov (%rsi,%rcx,8), %rax
bswap %rax
mov %rax, WB(%rsp,%rcx,8)
inc %rcx
cmp $16, %rcx
jb .Lxn_sha512_ld
mov $16, %ecx
.Lxn_sha512_sch:
mov (WB-16)(%rsp,%rcx,8), %rax
mov %rax, %rbx
ror $19, %rbx
mov %rax, %rdx
ror $61, %rdx
xor %rdx, %rbx
shr $6, %rax
xor %rax, %rbx
add (WB-56)(%rsp,%rcx,8), %rbx
mov (WB-120)(%rsp,%rcx,8), %rax
mov %rax, %rdx
ror $1, %rdx
mov %rax, %rsi
ror $8, %rsi
xor %rsi, %rdx
shr $7, %rax
xor %rax, %rdx
add %rdx, %rbx
add (WB-128)(%rsp,%rcx,8), %rbx
mov %rbx, WB(%rsp,%rcx,8)
inc %rcx
cmp $80, %rcx
jb .Lxn_sha512_sch
mov HB+0(%rsp), %r8
mov HB+8(%rsp), %r9
mov HB+16(%rsp), %r10
mov HB+24(%rsp), %r11
mov HB+32(%rsp), %r12
mov HB+40(%rsp), %r13
mov HB+48(%rsp), %r14
mov HB+56(%rsp), %r15
lea .Lxn_sha512_k(%rip), %rbp
lea WB(%rsp), %rdi
movq $80, CNT(%rsp)
.Lxn_sha512_rnd:
mov %r12, %rax
ror $14, %rax
mov %r12, %rbx
ror $18, %rbx
xor %rbx, %rax
mov %r12, %rbx
ror $41, %rbx
xor %rbx, %rax
mov %r13, %rbx
xor %r14, %rbx
and %r12, %rbx
xor %r14, %rbx
mov %r15, %rcx
add %rax, %rcx
add %rbx, %rcx
add (%rbp), %rcx
add (%rdi), %rcx
mov %r8, %rax
ror $28, %rax
mov %r8, %rbx
ror $34, %rbx
xor %rbx, %rax
mov %r8, %rbx
ror $39, %rbx
xor %rbx, %rax
mov %r8, %rbx
or %r9, %rbx
and %r10, %rbx
mov %r8, %rdx
and %r9, %rdx
or %rdx, %rbx
add %rbx, %rax
mov %r14, %r15
mov %r13, %r14
mov %r12, %r13
add %rcx, %r11
mov %r11, %r12
mov %r10, %r11
mov %r9, %r10
mov %r8, %r9
lea (%rcx,%rax), %r8
add $8, %rdi
add $8, %rbp
decq CNT(%rsp)
jnz .Lxn_sha512_rnd
add %r8, HB+0(%rsp)
add %r9, HB+8(%rsp)
add %r10, HB+16(%rsp)
add %r11, HB+24(%rsp)
add %r12, HB+32(%rsp)
add %r13, HB+40(%rsp)
add %r14, HB+48(%rsp)
add %r15, HB+56(%rsp)
ret
.balign 8
.Lxn_sha512_k:
.quad 0x428a2f98d728ae22, 0x7137449123ef65cd
.quad 0xb5c0fbcfec4d3b2f, 0xe9b5dba58189dbbc
.quad 0x3956c25bf348b538, 0x59f111f1b605d019
.quad 0x923f82a4af194f9b, 0xab1c5ed5da6d8118
.quad 0xd807aa98a3030242, 0x12835b0145706fbe
.quad 0x243185be4ee4b28c, 0x550c7dc3d5ffb4e2
.quad 0x72be5d74f27b896f, 0x80deb1fe3b1696b1
.quad 0x9bdc06a725c71235, 0xc19bf174cf692694
.quad 0xe49b69c19ef14ad2, 0xefbe4786384f25e3
.quad 0x0fc19dc68b8cd5b5, 0x240ca1cc77ac9c65
.quad 0x2de92c6f592b0275, 0x4a7484aa6ea6e483
.quad 0x5cb0a9dcbd41fbd4, 0x76f988da831153b5
.quad 0x983e5152ee66dfab, 0xa831c66d2db43210
.quad 0xb00327c898fb213f, 0xbf597fc7beef0ee4
.quad 0xc6e00bf33da88fc2, 0xd5a79147930aa725
.quad 0x06ca6351e003826f, 0x142929670a0e6e70
.quad 0x27b70a8546d22ffc, 0x2e1b21385c26c926
.quad 0x4d2c6dfc5ac42aed, 0x53380d139d95b3df
.quad 0x650a73548baf63de, 0x766a0abb3c77b2a8
.quad 0x81c2c92e47edaee6, 0x92722c851482353b
.quad 0xa2bfe8a14cf10364, 0xa81a664bbc423001
.quad 0xc24b8b70d0f89791, 0xc76c51a30654be30
.quad 0xd192e819d6ef5218, 0xd69906245565a910
.quad 0xf40e35855771202a, 0x106aa07032bbd1b8
.quad 0x19a4c116b8d2d0c8, 0x1e376c085141ab53
.quad 0x2748774cdf8eeb99, 0x34b0bcb5e19b48a8
.quad 0x391c0cb3c5c95a63, 0x4ed8aa4ae3418acb
.quad 0x5b9cca4f7763e373, 0x682e6ff3d6b2b8a3
.quad 0x748f82ee5defb2fc, 0x78a5636f43172f60
.quad 0x84c87814a1f0ab72, 0x8cc702081a6439ec
.quad 0x90befffa23631e28, 0xa4506cebde82bde9
.quad 0xbef9a3f7b2c67915, 0xc67178f2e372532b
.quad 0xca273eceea26619c, 0xd186b8c721c0c207
.quad 0xeada7dd6cde0eb1e, 0xf57d4f7fee6ed178
.quad 0x06f067aa72176fba, 0x0a637dc5a2c898a6
.quad 0x113f9804bef90dae, 0x1b710b35131c471b
.quad 0x28db77f523047d84, 0x32caab7b40c72493
.quad 0x3c9ebe0a15c9bebc, 0x431d67c49c100d4c
.quad 0x4cc5d4becb3e42b6, 0x597f299cfc657e2a
.quad 0x5fcb6fab3ad6faec, 0x6c44198c4a475817
.Lxn_sha512_iv:
.quad 0x6a09e667f3bcc908
.quad 0xbb67ae8584caa73b
.quad 0x3c6ef372fe94f82b
.quad 0xa54ff53a5f1d36f1
.quad 0x510e527fade682d1
.quad 0x9b05688c2b3e6c1f
.quad 0x1f83d9abfb41bd6b
.quad 0x5be0cd19137e2179

.text
.globl xn_fe_mul
.type xn_fe_mul,@function
.balign 16
xn_fe_mul:
push %rbx
push %rbp
push %r12
push %r13
push %r14
push %r15
sub $64, %rsp
mov %rdi, %rbx
mov %rsi, %rbp
mov %rdx, %r12
movq $0, 0(%rsp)
movq $0, 8(%rsp)
movq $0, 16(%rsp)
movq $0, 24(%rsp)
movq $0, 32(%rsp)
movq $0, 40(%rsp)
movq $0, 48(%rsp)
movq $0, 56(%rsp)
xor %r13d, %r13d
.Lxm_i:
mov (%rbp,%r13,8), %r8
xor %r15d, %r15d
xor %r14d, %r14d
.Lxm_j:
mov %r8, %rax
mulq (%r12,%r14,8)
add %r15, %rax
adc $0, %rdx
lea (%r13,%r14), %rcx
add (%rsp,%rcx,8), %rax
adc $0, %rdx
mov %rax, (%rsp,%rcx,8)
mov %rdx, %r15
inc %r14
cmp $4, %r14
jb .Lxm_j
lea 4(%r13), %rcx
mov %r15, (%rsp,%rcx,8)
inc %r13
cmp $4, %r13
jb .Lxm_i
xor %r15d, %r15d
xor %r14d, %r14d
.Lxm_f:
mov 32(%rsp,%r14,8), %rax
mov $38, %ecx
mul %rcx
add %r15, %rax
adc $0, %rdx
add (%rsp,%r14,8), %rax
adc $0, %rdx
mov %rax, (%rsp,%r14,8)
mov %rdx, %r15
inc %r14
cmp $4, %r14
jb .Lxm_f
mov %r15, %rax
mov $38, %ecx
mul %rcx
add %rax, (%rsp)
adcq $0, 8(%rsp)
adcq $0, 16(%rsp)
adcq $0, 24(%rsp)
setc %al
movzbl %al, %eax
test %eax, %eax
jz .Lxm_nc
addq $38, (%rsp)
adcq $0, 8(%rsp)
adcq $0, 16(%rsp)
adcq $0, 24(%rsp)
.Lxm_nc:
mov (%rsp), %r8
mov 8(%rsp), %r9
mov 16(%rsp), %r10
mov 24(%rsp), %r11
.rept 2
movabs $0xffffffffffffffed, %rcx
mov %r8, %r12
sub %rcx, %r12
mov $-1, %rax
mov %r9, %r13
sbb %rax, %r13
mov %r10, %r14
sbb %rax, %r14
movabs $0x7fffffffffffffff, %rcx
mov %r11, %r15
sbb %rcx, %r15
cmovae %r12, %r8
cmovae %r13, %r9
cmovae %r14, %r10
cmovae %r15, %r11
.endr
mov %r8, 0(%rbx)
mov %r9, 8(%rbx)
mov %r10, 16(%rbx)
mov %r11, 24(%rbx)
add $64, %rsp
pop %r15
pop %r14
pop %r13
pop %r12
pop %rbp
pop %rbx
ret

.globl xn_fe_add
.type xn_fe_add,@function
.balign 16
xn_fe_add:
mov (%rsi), %rax
add (%rdx), %rax
mov 8(%rsi), %rcx
adc 8(%rdx), %rcx
mov 16(%rsi), %r8
adc 16(%rdx), %r8
mov 24(%rsi), %r9
adc 24(%rdx), %r9
mov %rax, (%rdi)
mov %rcx, 8(%rdi)
mov %r8, 16(%rdi)
mov %r9, 24(%rdi)
movabs $0xffffffffffffffed, %r10
mov %rax, %r11
sub %r10, %r11
mov $-1, %r10
mov %rcx, %rdx
sbb %r10, %rdx
mov %r8, %rsi
sbb %r10, %rsi
movabs $0x7fffffffffffffff, %r10
mov %r9, %rax
sbb %r10, %rax
jb .Lxa_keep
mov %r11, (%rdi)
mov %rdx, 8(%rdi)
mov %rsi, 16(%rdi)
mov %rax, 24(%rdi)
.Lxa_keep:
ret

.globl xn_fe_sub
.type xn_fe_sub,@function
.balign 16
xn_fe_sub:
mov (%rsi), %rax
sub (%rdx), %rax
mov 8(%rsi), %rcx
sbb 8(%rdx), %rcx
mov 16(%rsi), %r8
sbb 16(%rdx), %r8
mov 24(%rsi), %r9
sbb 24(%rdx), %r9
sbb %r10, %r10
movabs $0xffffffffffffffed, %r11
and %r10, %r11
movabs $0x7fffffffffffffff, %rdx
and %r10, %rdx
add %r11, %rax
adc %r10, %rcx
adc %r10, %r8
adc %rdx, %r9
mov %rax, (%rdi)
mov %rcx, 8(%rdi)
mov %r8, 16(%rdi)
mov %r9, 24(%rdi)
ret

.globl xn_fe_pow
.type xn_fe_pow,@function
.balign 16
xn_fe_pow:
push %rbx
push %r12
push %r13
push %r14
sub $64, %rsp
mov %rdi, %rbx
mov %rsi, %r12
mov %rdx, %r13
movq $1, 0(%rsp)
movq $0, 8(%rsp)
movq $0, 16(%rsp)
movq $0, 24(%rsp)
mov $255, %r14
.Lxp_loop:
lea 32(%rsp), %rdi
mov %rsp, %rsi
mov %rsp, %rdx
call xn_fe_mul
mov 32(%rsp), %rax
mov %rax, 0(%rsp)
mov 40(%rsp), %rax
mov %rax, 8(%rsp)
mov 48(%rsp), %rax
mov %rax, 16(%rsp)
mov 56(%rsp), %rax
mov %rax, 24(%rsp)
mov %r14, %rcx
shr $6, %rcx
mov (%r13,%rcx,8), %rax
mov %r14, %rcx
and $63, %rcx
shr %cl, %rax
test $1, %al
jz .Lxp_skip
lea 32(%rsp), %rdi
mov %rsp, %rsi
mov %r12, %rdx
call xn_fe_mul
mov 32(%rsp), %rax
mov %rax, 0(%rsp)
mov 40(%rsp), %rax
mov %rax, 8(%rsp)
mov 48(%rsp), %rax
mov %rax, 16(%rsp)
mov 56(%rsp), %rax
mov %rax, 24(%rsp)
.Lxp_skip:
cmp $0, %r14
je .Lxp_done
dec %r14
jmp .Lxp_loop
.Lxp_done:
mov 0(%rsp), %rax
mov %rax, 0(%rbx)
mov 8(%rsp), %rax
mov %rax, 8(%rbx)
mov 16(%rsp), %rax
mov %rax, 16(%rbx)
mov 24(%rsp), %rax
mov %rax, 24(%rbx)
add $64, %rsp
pop %r14
pop %r13
pop %r12
pop %rbx
ret
.text
.macro FM dr, doff, ar, aoff, br, boff
lea \doff(\dr), %rdi
lea \aoff(\ar), %rsi
lea \boff(\br), %rdx
call xn_fe_mul
.endm
.macro FA dr, doff, ar, aoff, br, boff
lea \doff(\dr), %rdi
lea \aoff(\ar), %rsi
lea \boff(\br), %rdx
call xn_fe_add
.endm
.macro FS dr, doff, ar, aoff, br, boff
lea \doff(\dr), %rdi
lea \aoff(\ar), %rsi
lea \boff(\br), %rdx
call xn_fe_sub
.endm
.macro FMK dr, doff, ar, aoff, sym
lea \sym(%rip), %rdx
lea \aoff(\ar), %rsi
lea \doff(\dr), %rdi
call xn_fe_mul
.endm
.macro FAK dr, doff, ar, aoff, sym
lea \sym(%rip), %rdx
lea \aoff(\ar), %rsi
lea \doff(\dr), %rdi
call xn_fe_add
.endm
.macro FSK dr, doff, ar, aoff, sym
lea \sym(%rip), %rdx
lea \aoff(\ar), %rsi
lea \doff(\dr), %rdi
call xn_fe_sub
.endm
.macro FSZ dr, doff, br, boff
lea .Lxn_fe_zero(%rip), %rsi
lea \boff(\br), %rdx
lea \doff(\dr), %rdi
call xn_fe_sub
.endm

.globl xn_pt_add
.type xn_pt_add,@function
.balign 16
xn_pt_add:
push %rbx
push %rbp
push %r12
sub $512, %rsp
mov %rdi, %rbx
mov %rsi, %rbp
mov %rdx, %r12
FS %rsp, 0, %rbp, 32, %rbp, 0
FS %rsp, 32, %r12, 32, %r12, 0
FM %rsp, 64, %rsp, 0, %rsp, 32
FA %rsp, 96, %rbp, 32, %rbp, 0
FA %rsp, 128, %r12, 32, %r12, 0
FM %rsp, 160, %rsp, 96, %rsp, 128
FM %rsp, 192, %rbp, 96, %r12, 96
FMK %rsp, 224, %rsp, 192, .Lxn_fe_d2
FM %rsp, 256, %rbp, 64, %r12, 64
FA %rsp, 288, %rsp, 256, %rsp, 256
FS %rsp, 320, %rsp, 160, %rsp, 64
FS %rsp, 352, %rsp, 288, %rsp, 224
FA %rsp, 384, %rsp, 288, %rsp, 224
FA %rsp, 416, %rsp, 160, %rsp, 64
FM %rbx, 0, %rsp, 320, %rsp, 352
FM %rbx, 32, %rsp, 384, %rsp, 416
FM %rbx, 64, %rsp, 352, %rsp, 384
FM %rbx, 96, %rsp, 320, %rsp, 416
add $512, %rsp
pop %r12
pop %rbp
pop %rbx
ret

.globl xn_pt_dbl
.type xn_pt_dbl,@function
.balign 16
xn_pt_dbl:
push %rbx
push %rbp
sub $320, %rsp
mov %rdi, %rbx
mov %rsi, %rbp
FM %rsp, 0, %rbp, 0, %rbp, 0
FM %rsp, 32, %rbp, 32, %rbp, 32
FM %rsp, 64, %rbp, 64, %rbp, 64
FA %rsp, 64, %rsp, 64, %rsp, 64
FSZ %rsp, 96, %rsp, 0
FA %rsp, 128, %rbp, 0, %rbp, 32
FM %rsp, 160, %rsp, 128, %rsp, 128
FS %rsp, 192, %rsp, 160, %rsp, 0
FS %rsp, 192, %rsp, 192, %rsp, 32
FA %rsp, 224, %rsp, 96, %rsp, 32
FS %rsp, 256, %rsp, 224, %rsp, 64
FS %rsp, 288, %rsp, 96, %rsp, 32
FM %rbx, 0, %rsp, 192, %rsp, 256
FM %rbx, 32, %rsp, 224, %rsp, 288
FM %rbx, 64, %rsp, 256, %rsp, 224
FM %rbx, 96, %rsp, 192, %rsp, 288
add $320, %rsp
pop %rbp
pop %rbx
ret

.Lcopy128:
xor %ecx, %ecx
.Lcp128:
mov (%rsi,%rcx,8), %rax
mov %rax, (%rdi,%rcx,8)
inc %rcx
cmp $16, %rcx
jb .Lcp128
ret

.globl xn_pt_scalar
.type xn_pt_scalar,@function
.balign 16
xn_pt_scalar:
push %rbx
push %rbp
push %r12
push %r13
sub $256, %rsp
mov %rdi, %rbx
mov %rsi, %rbp
mov %rdx, %r12
mov %rsp, %rdi
lea .Lxn_pt_id(%rip), %rsi
call .Lcopy128
mov $255, %r13
.Lsm_loop:
lea 128(%rsp), %rdi
mov %rsp, %rsi
call xn_pt_dbl
mov %rsp, %rdi
lea 128(%rsp), %rsi
call .Lcopy128
mov %r13, %rcx
shr $6, %rcx
mov (%rbp,%rcx,8), %rax
mov %r13, %rcx
and $63, %rcx
shr %cl, %rax
test $1, %al
jz .Lsm_skip
lea 128(%rsp), %rdi
mov %rsp, %rsi
mov %r12, %rdx
call xn_pt_add
mov %rsp, %rdi
lea 128(%rsp), %rsi
call .Lcopy128
.Lsm_skip:
cmp $0, %r13
je .Lsm_done
dec %r13
jmp .Lsm_loop
.Lsm_done:
mov %rbx, %rdi
mov %rsp, %rsi
call .Lcopy128
add $256, %rsp
pop %r13
pop %r12
pop %rbp
pop %rbx
ret

.Lxn_fe_eq:
mov (%rdi), %rax
xor (%rsi), %rax
mov 8(%rdi), %rcx
xor 8(%rsi), %rcx
or %rcx, %rax
mov 16(%rdi), %rcx
xor 16(%rsi), %rcx
or %rcx, %rax
mov 24(%rdi), %rcx
xor 24(%rsi), %rcx
or %rcx, %rax
sete %al
movzbl %al, %eax
ret

.globl xn_pt_decompress
.type xn_pt_decompress,@function
.balign 16
xn_pt_decompress:
push %rbx
push %rbp
push %r12
sub $512, %rsp
mov %rdi, %rbx
mov %rsi, %rbp
mov %rdx, %r12
movq 0(%rbp), %rax
mov %rax, 0(%rsp)
movq 8(%rbp), %rax
mov %rax, 8(%rsp)
movq 16(%rbp), %rax
mov %rax, 16(%rsp)
movq 24(%rbp), %rax
mov %rax, 24(%rsp)
FM %rsp, 32, %rsp, 0, %rsp, 0
FSK %rsp, 64, %rsp, 32, .Lxn_fe_one
FMK %rsp, 96, %rsp, 32, .Lxn_fe_d
FAK %rsp, 96, %rsp, 96, .Lxn_fe_one
FM %rsp, 128, %rsp, 96, %rsp, 96
FM %rsp, 160, %rsp, 128, %rsp, 96
FM %rsp, 128, %rsp, 160, %rsp, 160
FM %rsp, 192, %rsp, 128, %rsp, 96
FM %rsp, 224, %rsp, 64, %rsp, 192
lea 256(%rsp), %rdi
lea 224(%rsp), %rsi
lea .Lxn_fe_pexp58(%rip), %rdx
call xn_fe_pow
FM %rsp, 288, %rsp, 64, %rsp, 160
FM %rsp, 320, %rsp, 288, %rsp, 256
FM %rsp, 352, %rsp, 320, %rsp, 320
FM %rsp, 352, %rsp, 352, %rsp, 96
lea 352(%rsp), %rdi
lea 64(%rsp), %rsi
call .Lxn_fe_eq
test %eax, %eax
jnz .Lxd_xok
FSZ %rsp, 384, %rsp, 64
lea 352(%rsp), %rdi
lea 384(%rsp), %rsi
call .Lxn_fe_eq
test %eax, %eax
jz .Lxd_bad
FMK %rsp, 320, %rsp, 320, .Lxn_fe_sqrtm1
.Lxd_xok:
lea 320(%rsp), %rdi
lea .Lxn_fe_zero(%rip), %rsi
call .Lxn_fe_eq
test %eax, %eax
jz .Lxd_nz
test %r12, %r12
jnz .Lxd_bad
.Lxd_nz:
mov 320(%rsp), %rax
and $1, %rax
cmp %r12, %rax
je .Lxd_out
FSZ %rsp, 320, %rsp, 320
.Lxd_out:
movq 320(%rsp), %rax
mov %rax, 0(%rbx)
movq 328(%rsp), %rax
mov %rax, 8(%rbx)
movq 336(%rsp), %rax
mov %rax, 16(%rbx)
movq 344(%rsp), %rax
mov %rax, 24(%rbx)
movq 0(%rsp), %rax
mov %rax, 32(%rbx)
movq 8(%rsp), %rax
mov %rax, 40(%rbx)
movq 16(%rsp), %rax
mov %rax, 48(%rbx)
movq 24(%rsp), %rax
mov %rax, 56(%rbx)
lea .Lxn_fe_one(%rip), %rsi
movq 0(%rsi), %rax
mov %rax, 64(%rbx)
movq 8(%rsi), %rax
mov %rax, 72(%rbx)
movq 16(%rsi), %rax
mov %rax, 80(%rbx)
movq 24(%rsi), %rax
mov %rax, 88(%rbx)
FM %rbx, 96, %rsp, 320, %rsp, 0
xor %eax, %eax
jmp .Lxd_ret
.Lxd_bad:
mov $1, %eax
.Lxd_ret:
add $512, %rsp
pop %r12
pop %rbp
pop %rbx
ret
.balign 8
.Lxn_fe_d:
.quad 0x75eb4dca135978a3, 0x00700a4d4141d8ab, 0x8cc740797779e898, 0x52036cee2b6ffe73
.balign 8
.Lxn_fe_d2:
.quad 0xebd69b9426b2f159, 0x00e0149a8283b156, 0x198e80f2eef3d130, 0x2406d9dc56dffce7
.balign 8
.Lxn_fe_sqrtm1:
.quad 0xc4ee1b274a0ea0b0, 0x2f431806ad2fe478, 0x2b4d00993dfbd7a7, 0x2b8324804fc1df0b
.balign 8
.Lxn_fe_one:
.quad 0x0000000000000001, 0x0000000000000000, 0x0000000000000000, 0x0000000000000000
.balign 8
.Lxn_fe_zero:
.quad 0x0000000000000000, 0x0000000000000000, 0x0000000000000000, 0x0000000000000000
.balign 8
.Lxn_fe_pexp58:
.quad 0xfffffffffffffffd, 0xffffffffffffffff, 0xffffffffffffffff, 0x0fffffffffffffff
.balign 8
.Lxn_pt_id:
.quad 0x0000000000000000, 0x0000000000000000, 0x0000000000000000, 0x0000000000000000
.quad 0x0000000000000001, 0x0000000000000000, 0x0000000000000000, 0x0000000000000000
.quad 0x0000000000000001, 0x0000000000000000, 0x0000000000000000, 0x0000000000000000
.quad 0x0000000000000000, 0x0000000000000000, 0x0000000000000000, 0x0000000000000000
.balign 8
.Lxn_pt_base:
.quad 0xc9562d608f25d51a, 0x692cc7609525a7b2, 0xc0a4e231fdd6dc5c, 0x216936d3cd6e53fe
.quad 0x6666666666666658, 0x6666666666666666, 0x6666666666666666, 0x6666666666666666
.quad 0x0000000000000001, 0x0000000000000000, 0x0000000000000000, 0x0000000000000000
.quad 0x6dde8ab3a5b7dda3, 0x20f09f80775152f5, 0x66ea4e8e64abe37d, 0x67875f0fd78b7665

.text
.Lvfy_cpq:
rep movsq
ret

.Lvfy_lt:
mov (%rdi), %rax
sub (%rsi), %rax
mov 8(%rdi), %rcx
sbb 8(%rsi), %rcx
mov 16(%rdi), %r8
sbb 16(%rsi), %r8
mov 24(%rdi), %r9
sbb 24(%rsi), %r9
setb %al
movzbl %al, %eax
ret

.Lvfy_eq:
mov (%rdi), %rax
xor (%rsi), %rax
mov 8(%rdi), %rcx
xor 8(%rsi), %rcx
or %rcx, %rax
mov 16(%rdi), %rcx
xor 16(%rsi), %rcx
or %rcx, %rax
mov 24(%rdi), %rcx
xor 24(%rsi), %rcx
or %rcx, %rax
sete %al
movzbl %al, %eax
ret

.globl xn_sc_reduce
.type xn_sc_reduce,@function
.balign 16
xn_sc_reduce:
push %rbx
push %rbp
push %r12
push %r13
push %r14
push %r15
xor %r8d, %r8d
xor %r9d, %r9d
xor %r10d, %r10d
xor %r11d, %r11d
mov $511, %r12
.Lsr_loop:
mov %r12, %rcx
shr $6, %rcx
mov (%rsi,%rcx,8), %rax
mov %r12, %rcx
and $63, %ecx
shr %cl, %rax
and $1, %eax
add %r8, %r8
adc %r9, %r9
adc %r10, %r10
adc %r11, %r11
add %rax, %r8
adc $0, %r9
adc $0, %r10
adc $0, %r11
movabs $0x5812631a5cf5d3ed, %r15
mov %r8, %rbp
sub %r15, %rbp
movabs $0x14def9dea2f79cd6, %r15
mov %r9, %rbx
sbb %r15, %rbx
mov %r10, %r13
sbb $0, %r13
movabs $0x1000000000000000, %r15
mov %r11, %r14
sbb %r15, %r14
jb .Lsr_keep
mov %rbp, %r8
mov %rbx, %r9
mov %r13, %r10
mov %r14, %r11
.Lsr_keep:
cmp $0, %r12
je .Lsr_done
dec %r12
jmp .Lsr_loop
.Lsr_done:
mov %r8, (%rdi)
mov %r9, 8(%rdi)
mov %r10, 16(%rdi)
mov %r11, 24(%rdi)
pop %r15
pop %r14
pop %r13
pop %r12
pop %rbp
pop %rbx
ret

.globl xn_ed_verify
.type xn_ed_verify,@function
.balign 16
xn_ed_verify:
push %rbx
push %rbp
push %r12
push %r13
push %r14
sub $1152, %rsp
mov %rdi, %rbx
mov %rsi, %rbp
mov %rdx, %r12
lea 1024(%rsp), %rdi
mov %rbx, %rsi
mov $4, %ecx
call .Lvfy_cpq
movzbl 31(%rbx), %r13d
shr $7, %r13d
andb $0x7f, 1055(%rsp)
lea 1024(%rsp), %rdi
lea .Lxn_fe_p(%rip), %rsi
call .Lvfy_lt
test %eax, %eax
jz .Lvfy_fail
mov %rsp, %rdi
lea 1024(%rsp), %rsi
mov %r13, %rdx
call xn_pt_decompress
test %eax, %eax
jnz .Lvfy_fail
lea 1024(%rsp), %rdi
mov %rbp, %rsi
mov $4, %ecx
call .Lvfy_cpq
movzbl 31(%rbp), %r14d
shr $7, %r14d
andb $0x7f, 1055(%rsp)
lea 1024(%rsp), %rdi
lea .Lxn_fe_p(%rip), %rsi
call .Lvfy_lt
test %eax, %eax
jz .Lvfy_fail
lea 128(%rsp), %rdi
lea 1024(%rsp), %rsi
mov %r14, %rdx
call xn_pt_decompress
test %eax, %eax
jnz .Lvfy_fail
lea 992(%rsp), %rdi
lea 32(%rbx), %rsi
mov $4, %ecx
call .Lvfy_cpq
lea 992(%rsp), %rdi
lea .Lxn_sc_L(%rip), %rsi
call .Lvfy_lt
test %eax, %eax
jz .Lvfy_fail
lea 768(%rsp), %rdi
mov %rbx, %rsi
mov $4, %ecx
call .Lvfy_cpq
lea 800(%rsp), %rdi
mov %rbp, %rsi
mov $4, %ecx
call .Lvfy_cpq
lea 832(%rsp), %rdi
mov %r12, %rsi
mov $8, %ecx
call .Lvfy_cpq
lea 768(%rsp), %rdi
mov $128, %esi
lea 896(%rsp), %rdx
call xn_sha512
lea 960(%rsp), %rdi
lea 896(%rsp), %rsi
call xn_sc_reduce
lea 256(%rsp), %rdi
lea .Lxn_fe_zero(%rip), %rsi
lea 128(%rsp), %rdx
call xn_fe_sub
lea 288(%rsp), %rdi
lea 160(%rsp), %rsi
mov $4, %ecx
call .Lvfy_cpq
lea 320(%rsp), %rdi
lea 192(%rsp), %rsi
mov $4, %ecx
call .Lvfy_cpq
lea 352(%rsp), %rdi
lea .Lxn_fe_zero(%rip), %rsi
lea 224(%rsp), %rdx
call xn_fe_sub
lea 384(%rsp), %rdi
lea 992(%rsp), %rsi
lea .Lxn_pt_base(%rip), %rdx
call xn_pt_scalar
lea 512(%rsp), %rdi
lea 960(%rsp), %rsi
lea 256(%rsp), %rdx
call xn_pt_scalar
lea 640(%rsp), %rdi
lea 384(%rsp), %rsi
lea 512(%rsp), %rdx
call xn_pt_add
lea 1056(%rsp), %rdi
mov %rsp, %rsi
lea 704(%rsp), %rdx
call xn_fe_mul
lea 640(%rsp), %rdi
lea 1056(%rsp), %rsi
call .Lvfy_eq
test %eax, %eax
jz .Lvfy_fail
lea 1088(%rsp), %rdi
lea 32(%rsp), %rsi
lea 704(%rsp), %rdx
call xn_fe_mul
lea 672(%rsp), %rdi
lea 1088(%rsp), %rsi
call .Lvfy_eq
test %eax, %eax
jz .Lvfy_fail
mov $1, %eax
jmp .Lvfy_ret
.Lvfy_fail:
xor %eax, %eax
.Lvfy_ret:
add $1152, %rsp
pop %r14
pop %r13
pop %r12
pop %rbp
pop %rbx
ret
.balign 8
.Lxn_sc_L:
.quad 0x5812631a5cf5d3ed, 0x14def9dea2f79cd6, 0x0000000000000000, 0x1000000000000000
.balign 8
.Lxn_fe_p:
.quad 0xffffffffffffffed, 0xffffffffffffffff, 0xffffffffffffffff, 0x7fffffffffffffff


.balign 16
.globl xn_code_end
xn_code_end:
.balign 16
.globl xn_cfg_start
xn_cfg_start:
.skip 96
.globl xn_stub_end
xn_stub_end:
)asm");

static const uint8_t xn_a64_stub[] = {
    0xfd, 0x7b, 0xb9, 0xa9, 0xf3, 0x53, 0x01, 0xa9, 0xf5, 0x5b, 0x02, 0xa9,
    0xf7, 0x63, 0x03, 0xa9, 0xf9, 0x6b, 0x04, 0xa9, 0xfb, 0x73, 0x05, 0xa9,
    0xff, 0x03, 0x11, 0xd1, 0xe0, 0x83, 0x00, 0xf9, 0xe1, 0x87, 0x00, 0xf9,
    0xe2, 0x8b, 0x00, 0xf9, 0xd3, 0xfe, 0xff, 0x10, 0xb4, 0x52, 0x00, 0x10,
    0x09, 0x2b, 0x88, 0xd2, 0x89, 0xa9, 0xaa, 0xf2, 0x49, 0xa8, 0xc8, 0xf2,
    0xc9, 0x09, 0xeb, 0xf2, 0x8a, 0x02, 0x40, 0xf9, 0x5f, 0x01, 0x09, 0xeb,
    0x80, 0x00, 0x00, 0x54, 0x21, 0x4a, 0x00, 0x10, 0x62, 0x03, 0x80, 0xd2,
    0xac, 0x01, 0x00, 0x14, 0x89, 0x06, 0x40, 0xf9, 0x6a, 0x02, 0x09, 0xcb,
    0xea, 0x03, 0x00, 0xf9, 0x89, 0x0a, 0x40, 0xf9, 0xe9, 0x07, 0x00, 0xf9,
    0x89, 0x0e, 0x40, 0xf9, 0xe9, 0x0b, 0x00, 0xf9, 0x89, 0x02, 0x01, 0x91,
    0xe9, 0x0f, 0x00, 0xf9, 0x80, 0x00, 0x80, 0xd2, 0x01, 0x00, 0x80, 0xd2,
    0xe8, 0x14, 0x80, 0xd2, 0x01, 0x00, 0x00, 0xd4, 0xa4, 0x01, 0x00, 0x94,
    0x00, 0x00, 0x80, 0xd2, 0x01, 0x00, 0x88, 0xd2, 0x62, 0x00, 0x80, 0xd2,
    0x43, 0x04, 0x80, 0xd2, 0x04, 0x00, 0x80, 0x92, 0x05, 0x00, 0x80, 0xd2,
    0xc8, 0x1b, 0x80, 0xd2, 0x01, 0x00, 0x00, 0xd4, 0xa0, 0x40, 0xf8, 0xb7,
    0xf6, 0x03, 0x00, 0xaa, 0xf6, 0x93, 0x00, 0xf9, 0xe9, 0x03, 0x40, 0xf9,
    0xc9, 0x02, 0x00, 0xf9, 0x89, 0x02, 0x01, 0x91, 0xc9, 0x06, 0x00, 0xf9,
    0x89, 0x0e, 0x40, 0xf9, 0xc9, 0x0a, 0x00, 0xf9, 0xdf, 0x0e, 0x00, 0xf9,
    0x01, 0x00, 0x88, 0xd2, 0xc1, 0x02, 0x01, 0x8b, 0x00, 0xe0, 0x81, 0x52,
    0xa0, 0x00, 0xa0, 0x72, 0x02, 0x00, 0x80, 0xd2, 0x03, 0x00, 0x80, 0xd2,
    0x04, 0x00, 0x80, 0xd2, 0x88, 0x1b, 0x80, 0xd2, 0x01, 0x00, 0x00, 0xd4,
    0x40, 0x3e, 0xf8, 0xb7, 0x80, 0x3e, 0x00, 0xb4, 0xed, 0x03, 0x13, 0xaa,
    0x0c, 0x50, 0x81, 0xd2, 0x6c, 0x02, 0x0c, 0x8b, 0xae, 0x64, 0x84, 0xd2,
    0x4e, 0x84, 0xb0, 0xf2, 0x8e, 0x9c, 0xd3, 0xf2, 0x4e, 0x7e, 0xf9, 0xf2,
    0x6f, 0x36, 0x80, 0xd2, 0x0f, 0x00, 0xa0, 0xf2, 0x0f, 0x20, 0xc0, 0xf2,
    0x0f, 0x00, 0xe0, 0xf2, 0xa9, 0x15, 0x40, 0x38, 0xce, 0x01, 0x09, 0xca,
    0xce, 0x7d, 0x0f, 0x9b, 0xbf, 0x01, 0x0c, 0xeb, 0x83, 0xff, 0xff, 0x54,
    0x15, 0x00, 0x80, 0xd2, 0xa9, 0x06, 0x00, 0x91, 0xaa, 0x82, 0x8f, 0xd2,
    0x4a, 0xe9, 0xaf, 0xf2, 0x2a, 0x37, 0xcf, 0xf2, 0xea, 0xc6, 0xf3, 0xf2,
    0x29, 0x7d, 0x0a, 0x9b, 0x29, 0x01, 0x0e, 0x8b, 0x2a, 0xfd, 0x5e, 0xd3,
    0x29, 0x01, 0x0a, 0xca, 0x2a, 0xb7, 0x9c, 0xd2, 0x8a, 0x9c, 0xa3, 0xf2,
    0xaa, 0xed, 0xc8, 0xf2, 0x0a, 0xeb, 0xf7, 0xf2, 0x29, 0x7d, 0x0a, 0x9b,
    0x2a, 0xfd, 0x5b, 0xd3, 0x29, 0x01, 0x0a, 0xca, 0x6a, 0x3d, 0x82, 0xd2,
    0x2a, 0x66, 0xa2, 0xf2, 0x6a, 0x37, 0xc9, 0xf2, 0x0a, 0x9a, 0xf2, 0xf2,
    0x29, 0x7d, 0x0a, 0x9b, 0x2a, 0xfd, 0x5f, 0xd3, 0x29, 0x01, 0x0a, 0xca,
    0xaa, 0xf2, 0x7d, 0xd3, 0x8b, 0x02, 0x0a, 0x8b, 0x6b, 0x11, 0x40, 0xf9,
    0x6b, 0x01, 0x09, 0xca, 0xec, 0x83, 0x00, 0x91, 0x8c, 0x01, 0x0a, 0x8b,
    0x8b, 0x01, 0x00, 0xf9, 0xb5, 0x06, 0x00, 0x91, 0xbf, 0x12, 0x00, 0xf1,
    0x03, 0xfc, 0xff, 0x54, 0xe9, 0x13, 0x40, 0xf9, 0xe9, 0x4b, 0x00, 0xf9,
    0xe9, 0x17, 0x40, 0xf9, 0xe9, 0x4f, 0x00, 0xf9, 0xe9, 0x1b, 0x40, 0xf9,
    0xe9, 0x53, 0x00, 0xf9, 0xe9, 0x1f, 0x40, 0xf9, 0xe9, 0x57, 0x00, 0xf9,
    0xa9, 0x0c, 0x8f, 0x52, 0x09, 0x2e, 0xac, 0x72, 0xe9, 0x83, 0x00, 0xb9,
    0xc9, 0x8d, 0x8c, 0x52, 0x09, 0x64, 0xa6, 0x72, 0xe9, 0x87, 0x00, 0xb9,
    0x49, 0xa6, 0x85, 0x52, 0x49, 0x2c, 0xaf, 0x72, 0xe9, 0x8b, 0x00, 0xb9,
    0x89, 0xae, 0x8c, 0x52, 0x09, 0x64, 0xad, 0x72, 0xe9, 0x8f, 0x00, 0xb9,
    0xe9, 0x0b, 0x40, 0xf9, 0xe9, 0x23, 0x00, 0xb4, 0x29, 0x05, 0x00, 0xd1,
    0xe9, 0x0b, 0x00, 0xf9, 0xe9, 0x0f, 0x40, 0xf9, 0x2a, 0x01, 0x40, 0xf9,
    0x2b, 0x05, 0x40, 0xf9, 0x2c, 0x09, 0x40, 0xf9, 0x29, 0x61, 0x00, 0x91,
    0xe9, 0x0f, 0x00, 0xf9, 0xea, 0x63, 0x00, 0xf9, 0xec, 0x6f, 0x00, 0xf9,
    0x6d, 0xfd, 0x78, 0xd3, 0xed, 0x6b, 0x00, 0xf9, 0x6b, 0xdd, 0x78, 0xd3,
    0x6b, 0xfd, 0x48, 0xd3, 0xeb, 0x67, 0x00, 0xf9, 0xeb, 0xfd, 0xff, 0xb4,
    0xed, 0x03, 0x40, 0xf9, 0x4e, 0x01, 0x0d, 0x8b, 0xee, 0x73, 0x00, 0xf9,
    0xcf, 0xfd, 0x4c, 0xd3, 0xef, 0xcd, 0x74, 0xd3, 0xd0, 0x01, 0x0b, 0x8b,
    0x10, 0xfe, 0x3f, 0x91, 0x10, 0xfe, 0x4c, 0xd3, 0x10, 0xce, 0x74, 0xd3,
    0x01, 0x02, 0x0f, 0xcb, 0xe0, 0x03, 0x0f, 0xaa, 0x62, 0x00, 0x80, 0xd2,
    0x48, 0x1c, 0x80, 0xd2, 0x01, 0x00, 0x00, 0xd4, 0x80, 0x22, 0x00, 0xb5,
    0xe9, 0x63, 0x40, 0xf9, 0xe9, 0xb7, 0x00, 0xb9, 0x2a, 0xfd, 0x60, 0xd3,
    0xea, 0xbb, 0x00, 0xb9, 0xeb, 0x67, 0x40, 0xf9, 0xeb, 0xbf, 0x00, 0xb9,
    0xff, 0xb3, 0x00, 0xb9, 0xe9, 0x67, 0x40, 0xf9, 0xe9, 0x77, 0x00, 0xf9,
    0xe9, 0x73, 0x40, 0xf9, 0xe9, 0x7b, 0x00, 0xf9, 0xe0, 0x83, 0x40, 0xb9,
    0xe1, 0x87, 0x40, 0xb9, 0xe2, 0x8b, 0x40, 0xb9, 0xe3, 0x8f, 0x40, 0xb9,
    0xe4, 0x93, 0x40, 0xb9, 0xe5, 0x97, 0x40, 0xb9, 0xe6, 0x9b, 0x40, 0xb9,
    0xe7, 0x9f, 0x40, 0xb9, 0xe8, 0xa3, 0x40, 0xb9, 0xe9, 0xa7, 0x40, 0xb9,
    0xea, 0xab, 0x40, 0xb9, 0xeb, 0xaf, 0x40, 0xb9, 0xec, 0xb3, 0x40, 0xb9,
    0xed, 0xb7, 0x40, 0xb9, 0xee, 0xbb, 0x40, 0xb9, 0xef, 0xbf, 0x40, 0xb9,
    0x51, 0x01, 0x80, 0x52, 0x00, 0x00, 0x04, 0x0b, 0x8c, 0x01, 0x00, 0x4a,
    0x8c, 0x41, 0x8c, 0x13, 0x08, 0x01, 0x0c, 0x0b, 0x84, 0x00, 0x08, 0x4a,
    0x84, 0x50, 0x84, 0x13, 0x00, 0x00, 0x04, 0x0b, 0x8c, 0x01, 0x00, 0x4a,
    0x8c, 0x61, 0x8c, 0x13, 0x08, 0x01, 0x0c, 0x0b, 0x84, 0x00, 0x08, 0x4a,
    0x84, 0x64, 0x84, 0x13, 0x21, 0x00, 0x05, 0x0b, 0xad, 0x01, 0x01, 0x4a,
    0xad, 0x41, 0x8d, 0x13, 0x29, 0x01, 0x0d, 0x0b, 0xa5, 0x00, 0x09, 0x4a,
    0xa5, 0x50, 0x85, 0x13, 0x21, 0x00, 0x05, 0x0b, 0xad, 0x01, 0x01, 0x4a,
    0xad, 0x61, 0x8d, 0x13, 0x29, 0x01, 0x0d, 0x0b, 0xa5, 0x00, 0x09, 0x4a,
    0xa5, 0x64, 0x85, 0x13, 0x42, 0x00, 0x06, 0x0b, 0xce, 0x01, 0x02, 0x4a,
    0xce, 0x41, 0x8e, 0x13, 0x4a, 0x01, 0x0e, 0x0b, 0xc6, 0x00, 0x0a, 0x4a,
    0xc6, 0x50, 0x86, 0x13, 0x42, 0x00, 0x06, 0x0b, 0xce, 0x01, 0x02, 0x4a,
    0xce, 0x61, 0x8e, 0x13, 0x4a, 0x01, 0x0e, 0x0b, 0xc6, 0x00, 0x0a, 0x4a,
    0xc6, 0x64, 0x86, 0x13, 0x63, 0x00, 0x07, 0x0b, 0xef, 0x01, 0x03, 0x4a,
    0xef, 0x41, 0x8f, 0x13, 0x6b, 0x01, 0x0f, 0x0b, 0xe7, 0x00, 0x0b, 0x4a,
    0xe7, 0x50, 0x87, 0x13, 0x63, 0x00, 0x07, 0x0b, 0xef, 0x01, 0x03, 0x4a,
    0xef, 0x61, 0x8f, 0x13, 0x6b, 0x01, 0x0f, 0x0b, 0xe7, 0x00, 0x0b, 0x4a,
    0xe7, 0x64, 0x87, 0x13, 0x00, 0x00, 0x05, 0x0b, 0xef, 0x01, 0x00, 0x4a,
    0xef, 0x41, 0x8f, 0x13, 0x4a, 0x01, 0x0f, 0x0b, 0xa5, 0x00, 0x0a, 0x4a,
    0xa5, 0x50, 0x85, 0x13, 0x00, 0x00, 0x05, 0x0b, 0xef, 0x01, 0x00, 0x4a,
    0xef, 0x61, 0x8f, 0x13, 0x4a, 0x01, 0x0f, 0x0b, 0xa5, 0x00, 0x0a, 0x4a,
    0xa5, 0x64, 0x85, 0x13, 0x21, 0x00, 0x06, 0x0b, 0x8c, 0x01, 0x01, 0x4a,
    0x8c, 0x41, 0x8c, 0x13, 0x6b, 0x01, 0x0c, 0x0b, 0xc6, 0x00, 0x0b, 0x4a,
    0xc6, 0x50, 0x86, 0x13, 0x21, 0x00, 0x06, 0x0b, 0x8c, 0x01, 0x01, 0x4a,
    0x8c, 0x61, 0x8c, 0x13, 0x6b, 0x01, 0x0c, 0x0b, 0xc6, 0x00, 0x0b, 0x4a,
    0xc6, 0x64, 0x86, 0x13, 0x42, 0x00, 0x07, 0x0b, 0xad, 0x01, 0x02, 0x4a,
    0xad, 0x41, 0x8d, 0x13, 0x08, 0x01, 0x0d, 0x0b, 0xe7, 0x00, 0x08, 0x4a,
    0xe7, 0x50, 0x87, 0x13, 0x42, 0x00, 0x07, 0x0b, 0xad, 0x01, 0x02, 0x4a,
    0xad, 0x61, 0x8d, 0x13, 0x08, 0x01, 0x0d, 0x0b, 0xe7, 0x00, 0x08, 0x4a,
    0xe7, 0x64, 0x87, 0x13, 0x63, 0x00, 0x04, 0x0b, 0xce, 0x01, 0x03, 0x4a,
    0xce, 0x41, 0x8e, 0x13, 0x29, 0x01, 0x0e, 0x0b, 0x84, 0x00, 0x09, 0x4a,
    0x84, 0x50, 0x84, 0x13, 0x63, 0x00, 0x04, 0x0b, 0xce, 0x01, 0x03, 0x4a,
    0xce, 0x61, 0x8e, 0x13, 0x29, 0x01, 0x0e, 0x0b, 0x84, 0x00, 0x09, 0x4a,
    0x84, 0x64, 0x84, 0x13, 0x31, 0x06, 0x00, 0x71, 0xe1, 0xf3, 0xff, 0x54,
    0xf0, 0x83, 0x40, 0xb9, 0x00, 0x00, 0x10, 0x0b, 0xf0, 0x87, 0x40, 0xb9,
    0x21, 0x00, 0x10, 0x0b, 0xf0, 0x8b, 0x40, 0xb9, 0x42, 0x00, 0x10, 0x0b,
    0xf0, 0x8f, 0x40, 0xb9, 0x63, 0x00, 0x10, 0x0b, 0xf0, 0x93, 0x40, 0xb9,
    0x84, 0x00, 0x10, 0x0b, 0xf0, 0x97, 0x40, 0xb9, 0xa5, 0x00, 0x10, 0x0b,
    0xf0, 0x9b, 0x40, 0xb9, 0xc6, 0x00, 0x10, 0x0b, 0xf0, 0x9f, 0x40, 0xb9,
    0xe7, 0x00, 0x10, 0x0b, 0xf0, 0xa3, 0x40, 0xb9, 0x08, 0x01, 0x10, 0x0b,
    0xf0, 0xa7, 0x40, 0xb9, 0x29, 0x01, 0x10, 0x0b, 0xf0, 0xab, 0x40, 0xb9,
    0x4a, 0x01, 0x10, 0x0b, 0xf0, 0xaf, 0x40, 0xb9, 0x6b, 0x01, 0x10, 0x0b,
    0xf0, 0xb3, 0x40, 0xb9, 0x8c, 0x01, 0x10, 0x0b, 0xf0, 0xb7, 0x40, 0xb9,
    0xad, 0x01, 0x10, 0x0b, 0xf0, 0xbb, 0x40, 0xb9, 0xce, 0x01, 0x10, 0x0b,
    0xf0, 0xbf, 0x40, 0xb9, 0xef, 0x01, 0x10, 0x0b, 0xe0, 0x43, 0x00, 0xb9,
    0xe1, 0x47, 0x00, 0xb9, 0xe2, 0x4b, 0x00, 0xb9, 0xe3, 0x4f, 0x00, 0xb9,
    0xe4, 0x53, 0x00, 0xb9, 0xe5, 0x57, 0x00, 0xb9, 0xe6, 0x5b, 0x00, 0xb9,
    0xe7, 0x5f, 0x00, 0xb9, 0xe8, 0x63, 0x00, 0xb9, 0xe9, 0x67, 0x00, 0xb9,
    0xea, 0x6b, 0x00, 0xb9, 0xeb, 0x6f, 0x00, 0xb9, 0xec, 0x73, 0x00, 0xb9,
    0xed, 0x77, 0x00, 0xb9, 0xee, 0x7b, 0x00, 0xb9, 0xef, 0x7f, 0x00, 0xb9,
    0xe9, 0x77, 0x40, 0xf9, 0x0a, 0x08, 0x80, 0xd2, 0x3f, 0x01, 0x0a, 0xeb,
    0x2a, 0x31, 0x8a, 0x9a, 0xeb, 0x7b, 0x40, 0xf9, 0xee, 0x03, 0x01, 0x91,
    0xec, 0x03, 0x0a, 0xaa, 0xcd, 0x15, 0x40, 0x38, 0x6f, 0x01, 0x40, 0x39,
    0xef, 0x01, 0x0d, 0x4a, 0x6f, 0x15, 0x00, 0x38, 0x8c, 0x05, 0x00, 0xf1,
    0x61, 0xff, 0xff, 0x54, 0xeb, 0x7b, 0x00, 0xf9, 0xe9, 0x77, 0x40, 0xf9,
    0x29, 0x01, 0x0a, 0xcb, 0xe9, 0x77, 0x00, 0xf9, 0xec, 0xb3, 0x40, 0xb9,
    0x8c, 0x05, 0x00, 0x11, 0xec, 0xb3, 0x00, 0xb9, 0x29, 0xe9, 0xff, 0xb5,
    0xe9, 0x73, 0x40, 0xf9, 0xea, 0x67, 0x40, 0xf9, 0x2a, 0x01, 0x0a, 0x8b,
    0xab, 0x64, 0x84, 0xd2, 0x4b, 0x84, 0xb0, 0xf2, 0x8b, 0x9c, 0xd3, 0xf2,
    0x4b, 0x7e, 0xf9, 0xf2, 0x6c, 0x36, 0x80, 0xd2, 0x0c, 0x00, 0xa0, 0xf2,
    0x0c, 0x20, 0xc0, 0xf2, 0x0c, 0x00, 0xe0, 0xf2, 0x3f, 0x01, 0x0a, 0xeb,
    0xa2, 0x00, 0x00, 0x54, 0x2d, 0x15, 0x40, 0x38, 0x6b, 0x01, 0x0d, 0xca,
    0x6b, 0x7d, 0x0c, 0x9b, 0xfb, 0xff, 0xff, 0x17, 0xed, 0x6f, 0x40, 0xf9,
    0x7f, 0x01, 0x0d, 0xeb, 0x01, 0x08, 0x00, 0x54, 0xe9, 0x73, 0x40, 0xf9,
    0xeb, 0x67, 0x40, 0xf9, 0x2a, 0xfd, 0x4c, 0xd3, 0x4a, 0xcd, 0x74, 0xd3,
    0x2c, 0x01, 0x0b, 0x8b, 0x8c, 0xfd, 0x3f, 0x91, 0x8c, 0xfd, 0x4c, 0xd3,
    0x8c, 0xcd, 0x74, 0xd3, 0x81, 0x01, 0x0a, 0xcb, 0xe0, 0x03, 0x0a, 0xaa,
    0xe2, 0x6b, 0x40, 0xf9, 0x48, 0x1c, 0x80, 0xd2, 0x01, 0x00, 0x00, 0xd4,
    0xe0, 0x05, 0x00, 0xb5, 0xe9, 0x73, 0x40, 0xf9, 0xeb, 0x67, 0x40, 0xf9,
    0x2c, 0x01, 0x0b, 0x8b, 0x2e, 0x00, 0x3b, 0xd5, 0xcf, 0x4d, 0x50, 0xd3,
    0x90, 0x00, 0x80, 0xd2, 0x0f, 0x22, 0xcf, 0x9a, 0xf1, 0x05, 0x00, 0xd1,
    0x2d, 0x01, 0x31, 0x8a, 0x2d, 0x7b, 0x0b, 0xd5, 0xad, 0x01, 0x0f, 0x8b,
    0xbf, 0x01, 0x0c, 0xeb, 0xa3, 0xff, 0xff, 0x54, 0x9f, 0x3b, 0x03, 0xd5,
    0xcf, 0x0d, 0x40, 0x92, 0x90, 0x00, 0x80, 0xd2, 0x0f, 0x22, 0xcf, 0x9a,
    0xf1, 0x05, 0x00, 0xd1, 0x2d, 0x01, 0x31, 0x8a, 0x2d, 0x75, 0x0b, 0xd5,
    0xad, 0x01, 0x0f, 0x8b, 0xbf, 0x01, 0x0c, 0xeb, 0xa3, 0xff, 0xff, 0x54,
    0x9f, 0x3b, 0x03, 0xd5, 0xdf, 0x3f, 0x03, 0xd5, 0xe1, 0xfe, 0xff, 0x17,
    0xe9, 0x93, 0x40, 0xf9, 0x29, 0x61, 0x00, 0x91, 0x2a, 0x00, 0x80, 0xd2,
    0x2a, 0xfd, 0x9f, 0xc8, 0xe9, 0x07, 0x40, 0xf9, 0xe9, 0x00, 0x00, 0xb4,
    0xea, 0x03, 0x40, 0xf9, 0x29, 0x01, 0x0a, 0x8b, 0xe0, 0x83, 0x40, 0xf9,
    0xe1, 0x87, 0x40, 0xf9, 0xe2, 0x8b, 0x40, 0xf9, 0x20, 0x01, 0x3f, 0xd6,
    0xff, 0x03, 0x11, 0x91, 0xfb, 0x73, 0x45, 0xa9, 0xf9, 0x6b, 0x44, 0xa9,
    0xf7, 0x63, 0x43, 0xa9, 0xf5, 0x5b, 0x42, 0xa9, 0xf3, 0x53, 0x41, 0xa9,
    0xfd, 0x7b, 0xc7, 0xa8, 0xc0, 0x03, 0x5f, 0xd6, 0xc1, 0x16, 0x00, 0x50,
    0x42, 0x06, 0x80, 0xd2, 0x04, 0x00, 0x00, 0x14, 0x01, 0x18, 0x00, 0x10,
    0xa2, 0x04, 0x80, 0xd2, 0x01, 0x00, 0x00, 0x14, 0x40, 0x00, 0x80, 0xd2,
    0x08, 0x08, 0x80, 0xd2, 0x01, 0x00, 0x00, 0xd4, 0x20, 0x00, 0x80, 0xd2,
    0xc8, 0x0b, 0x80, 0xd2, 0x01, 0x00, 0x00, 0xd4, 0xff, 0x03, 0x21, 0xd1,
    0xfe, 0x1b, 0x04, 0xf9, 0x60, 0x0c, 0x80, 0x92, 0xa1, 0x19, 0x00, 0x30,
    0x02, 0x00, 0x88, 0xd2, 0x08, 0x07, 0x80, 0xd2, 0x01, 0x00, 0x00, 0xd4,
    0xa0, 0x0b, 0xf8, 0xb7, 0xe0, 0x03, 0x04, 0xf9, 0xe0, 0x03, 0x44, 0xf9,
    0xe1, 0x03, 0x00, 0x91, 0x02, 0x80, 0x80, 0xd2, 0xa8, 0x07, 0x80, 0xd2,
    0x01, 0x00, 0x00, 0xd4, 0xc0, 0x0a, 0xf8, 0xb7, 0x60, 0x06, 0x00, 0xb4,
    0xe0, 0x13, 0x04, 0xf9, 0xff, 0x0f, 0x04, 0xf9, 0xe9, 0x0f, 0x44, 0xf9,
    0xea, 0x13, 0x44, 0xf9, 0x3f, 0x01, 0x0a, 0xeb, 0x82, 0xfe, 0xff, 0x54,
    0xeb, 0x03, 0x00, 0x91, 0x6b, 0x01, 0x09, 0x8b, 0x6c, 0x21, 0x40, 0x79,
    0x6c, 0x09, 0x00, 0x34, 0x29, 0x01, 0x0c, 0x8b, 0xe9, 0x0f, 0x04, 0xf9,
    0x6d, 0x4d, 0x40, 0x39, 0xbf, 0xc1, 0x00, 0x71, 0x83, 0xfe, 0xff, 0x54,
    0xbf, 0xe5, 0x00, 0x71, 0x48, 0xfe, 0xff, 0x54, 0xe0, 0x03, 0x44, 0xf9,
    0x61, 0x4d, 0x00, 0x91, 0x02, 0x00, 0x88, 0xd2, 0x08, 0x07, 0x80, 0xd2,
    0x01, 0x00, 0x00, 0xd4, 0x80, 0xfd, 0xff, 0xb7, 0xe0, 0x07, 0x04, 0xf9,
    0xe0, 0x07, 0x44, 0xf9, 0x61, 0x15, 0x00, 0x30, 0x02, 0x00, 0x80, 0xd2,
    0x03, 0x00, 0x80, 0xd2, 0x08, 0x07, 0x80, 0xd2, 0x01, 0x00, 0x00, 0xd4,
    0x00, 0x02, 0xf8, 0xb7, 0xe0, 0x0b, 0x04, 0xf9, 0xe1, 0x03, 0x10, 0x91,
    0xe2, 0x7f, 0x80, 0xd2, 0xe8, 0x07, 0x80, 0xd2, 0x01, 0x00, 0x00, 0xd4,
    0xe0, 0x17, 0x04, 0xf9, 0xe0, 0x0b, 0x44, 0xf9, 0x28, 0x07, 0x80, 0xd2,
    0x01, 0x00, 0x00, 0xd4, 0xe2, 0x17, 0x44, 0xf9, 0x5f, 0x00, 0x00, 0xf1,
    0x8d, 0x00, 0x00, 0x54, 0xe1, 0x03, 0x10, 0x91, 0x22, 0x00, 0x02, 0x8b,
    0x0b, 0x00, 0x00, 0x94, 0xe0, 0x07, 0x44, 0xf9, 0x28, 0x07, 0x80, 0xd2,
    0x01, 0x00, 0x00, 0xd4, 0xd1, 0xff, 0xff, 0x17, 0xe0, 0x03, 0x44, 0xf9,
    0x28, 0x07, 0x80, 0xd2, 0x01, 0x00, 0x00, 0xd4, 0xfe, 0x1b, 0x44, 0xf9,
    0xff, 0x03, 0x21, 0x91, 0xc0, 0x03, 0x5f, 0xd6, 0xc5, 0x11, 0x00, 0x10,
    0x29, 0x28, 0x00, 0x91, 0x3f, 0x01, 0x02, 0xeb, 0x28, 0x03, 0x00, 0x54,
    0x0a, 0x00, 0x80, 0xd2, 0x5f, 0x29, 0x00, 0xf1, 0x22, 0x01, 0x00, 0x54,
    0x2b, 0x68, 0x6a, 0x38, 0xac, 0x68, 0x6a, 0x38, 0x7f, 0x01, 0x0c, 0x6b,
    0x61, 0x00, 0x00, 0x54, 0x4a, 0x05, 0x00, 0x91, 0xf9, 0xff, 0xff, 0x17,
    0x21, 0x04, 0x00, 0x91, 0xf3, 0xff, 0xff, 0x17, 0x21, 0x28, 0x00, 0x91,
    0x3f, 0x00, 0x02, 0xeb, 0x62, 0x01, 0x00, 0x54, 0x2b, 0x00, 0x40, 0x39,
    0x7f, 0x81, 0x00, 0x71, 0xc0, 0x00, 0x00, 0x54, 0x7f, 0x25, 0x00, 0x71,
    0x80, 0x00, 0x00, 0x54, 0x7f, 0xc1, 0x00, 0x71, 0xe1, 0x00, 0x00, 0x54,
    0xc0, 0x03, 0x5f, 0xd6, 0x21, 0x04, 0x00, 0x91, 0xf5, 0xff, 0xff, 0x17,
    0x81, 0x0b, 0x00, 0x30, 0x62, 0x04, 0x80, 0xd2, 0x94, 0xff, 0xff, 0x17,
    0x81, 0x07, 0x00, 0x70, 0x62, 0x03, 0x80, 0xd2, 0x91, 0xff, 0xff, 0x17,
    0xe1, 0x0b, 0x00, 0x10, 0xa2, 0x03, 0x80, 0xd2, 0x8e, 0xff, 0xff, 0x17,
    0xff, 0x43, 0x00, 0xd1, 0xff, 0x03, 0x00, 0xf9, 0x09, 0xa0, 0x8c, 0xd2,
    0xa9, 0xb9, 0xa3, 0xf2, 0xe9, 0x07, 0x00, 0xf9, 0x8e, 0xff, 0xff, 0x97,
    0xc9, 0x62, 0x00, 0x91, 0x29, 0xfd, 0xdf, 0xc8, 0x49, 0x00, 0x00, 0xb4,
    0x06, 0x00, 0x00, 0x94, 0xe0, 0x03, 0x00, 0x91, 0x01, 0x00, 0x80, 0xd2,
    0xa8, 0x0c, 0x80, 0xd2, 0x01, 0x00, 0x00, 0xd4, 0xf7, 0xff, 0xff, 0x17,
    0xcd, 0x06, 0x40, 0xf9, 0xce, 0x0a, 0x40, 0xf9, 0x0f, 0x00, 0x80, 0xd2,
    0xff, 0x01, 0x0e, 0xeb, 0x82, 0x03, 0x00, 0x54, 0xe9, 0x05, 0x0f, 0x8b,
    0xaa, 0x0d, 0x09, 0x8b, 0x4b, 0x01, 0x40, 0xf9, 0xcc, 0x02, 0x40, 0xf9,
    0x6b, 0x01, 0x0c, 0x8b, 0x4c, 0x05, 0x40, 0xf9, 0x8c, 0xdd, 0x78, 0xd3,
    0x8c, 0xfd, 0x48, 0xd3, 0xb0, 0x64, 0x84, 0xd2, 0x50, 0x84, 0xb0, 0xf2,
    0x90, 0x9c, 0xd3, 0xf2, 0x50, 0x7e, 0xf9, 0xf2, 0x71, 0x36, 0x80, 0xd2,
    0x11, 0x00, 0xa0, 0xf2, 0x11, 0x20, 0xc0, 0xf2, 0x11, 0x00, 0xe0, 0xf2,
    0xcc, 0x00, 0x00, 0xb4, 0x69, 0x15, 0x40, 0x38, 0x10, 0x02, 0x09, 0xca,
    0x10, 0x7e, 0x11, 0x9b, 0x8c, 0x05, 0x00, 0xd1, 0xfb, 0xff, 0xff, 0x17,
    0x49, 0x09, 0x40, 0xf9, 0x1f, 0x02, 0x09, 0xeb, 0xc1, 0xeb, 0xff, 0x54,
    0xef, 0x05, 0x00, 0x91, 0xe4, 0xff, 0xff, 0x17, 0xc0, 0x03, 0x5f, 0xd6,
    0x58, 0x4e, 0x65, 0x62, 0x75, 0x6c, 0x61, 0x3a, 0x20, 0x62, 0x61, 0x64,
    0x20, 0x63, 0x6f, 0x6e, 0x66, 0x69, 0x67, 0x75, 0x72, 0x61, 0x74, 0x69,
    0x6f, 0x6e, 0x0a, 0x58, 0x4e, 0x65, 0x62, 0x75, 0x6c, 0x61, 0x3a, 0x20,
    0x64, 0x65, 0x62, 0x75, 0x67, 0x67, 0x65, 0x72, 0x20, 0x64, 0x65, 0x74,
    0x65, 0x63, 0x74, 0x65, 0x64, 0x0a, 0x58, 0x4e, 0x65, 0x62, 0x75, 0x6c,
    0x61, 0x3a, 0x20, 0x6d, 0x70, 0x72, 0x6f, 0x74, 0x65, 0x63, 0x74, 0x20,
    0x72, 0x65, 0x66, 0x75, 0x73, 0x65, 0x64, 0x20, 0x28, 0x53, 0x45, 0x4c,
    0x69, 0x6e, 0x75, 0x78, 0x20, 0x6f, 0x72, 0x20, 0x57, 0x5e, 0x58, 0x20,
    0x70, 0x6f, 0x6c, 0x69, 0x63, 0x79, 0x29, 0x0a, 0x58, 0x4e, 0x65, 0x62,
    0x75, 0x6c, 0x61, 0x3a, 0x20, 0x63, 0x6f, 0x64, 0x65, 0x20, 0x69, 0x6e,
    0x74, 0x65, 0x67, 0x72, 0x69, 0x74, 0x79, 0x20, 0x63, 0x68, 0x65, 0x63,
    0x6b, 0x20, 0x66, 0x61, 0x69, 0x6c, 0x65, 0x64, 0x0a, 0x58, 0x4e, 0x65,
    0x62, 0x75, 0x6c, 0x61, 0x3a, 0x20, 0x70, 0x72, 0x6f, 0x63, 0x65, 0x73,
    0x73, 0x20, 0x73, 0x74, 0x61, 0x74, 0x65, 0x20, 0x75, 0x6e, 0x61, 0x76,
    0x61, 0x69, 0x6c, 0x61, 0x62, 0x6c, 0x65, 0x0a, 0x58, 0x4e, 0x65, 0x62,
    0x75, 0x6c, 0x61, 0x3a, 0x20, 0x6d, 0x6f, 0x6e, 0x69, 0x74, 0x6f, 0x72,
    0x20, 0x75, 0x6e, 0x61, 0x76, 0x61, 0x69, 0x6c, 0x61, 0x62, 0x6c, 0x65,
    0x0a, 0x2f, 0x70, 0x72, 0x6f, 0x63, 0x2f, 0x73, 0x65, 0x6c, 0x66, 0x2f,
    0x74, 0x61, 0x73, 0x6b, 0x00, 0x73, 0x74, 0x61, 0x74, 0x75, 0x73, 0x00,
    0x54, 0x72, 0x61, 0x63, 0x65, 0x72, 0x50, 0x69, 0x64, 0x3a, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00,
};
constexpr uint64_t XN_A64_CODE_LEN = 0xa80;

extern "C" {
extern uint8_t xn_stub_start[];
extern uint8_t xn_code_end[];
extern uint8_t xn_cfg_start[];
extern uint8_t xn_stub_end[];
}

constexpr uint64_t XN_MAGIC = 0x584e4542554c4158ULL;
constexpr uint64_t XN_CFG_HDR = 96;
constexpr uint64_t XN_ENTRY = 80;
constexpr uint64_t XN_SIG = 64;
constexpr uint64_t XN_DT_SYMTAB_SHNDX = 0x6ffffef6ULL;
constexpr uint64_t XN_DT_RELR = 36;
constexpr uint64_t XN_DT_RELRSZ = 35;

struct Interval {
    uint64_t addr;
    uint64_t size;
};

struct ProtRange {
    uint64_t addr;
    uint64_t size;
    uint64_t prot;
    uint64_t foff;
    uint8_t digest[64];
};

static void xn_fail(const char *msg) {
    std::fprintf(stderr, "XNebula Protector: %s\n", msg);
    std::exit(1);
}

static uint64_t xn_end(uint64_t a, uint64_t s) {
    if (a >= ~0ULL) return ~0ULL;
    if (s > ~0ULL - a) return ~0ULL;
    return a + s;
}

static uint64_t align_up(uint64_t v, uint64_t a) {
    uint64_t m = a - 1;
    if (v > ~0ULL - m) return ~0ULL;
    return (v + m) & ~m;
}

static uint64_t align_down(uint64_t v, uint64_t a) {
    return v & ~(a - 1);
}

static std::vector<Interval> xn_normalize(std::vector<Interval> v) {
    std::sort(v.begin(), v.end(), [](const Interval &a, const Interval &b) {
        if (a.addr != b.addr) return a.addr < b.addr;
        return a.size < b.size;
    });

    std::vector<Interval> out;
    for (auto x : v) {
        if (x.size == 0) continue;
        uint64_t e = xn_end(x.addr, x.size);

        if (out.empty()) {
            out.push_back(x);
            continue;
        }

        uint64_t ce = xn_end(out.back().addr, out.back().size);
        if (x.addr > ce) {
            out.push_back(x);
        } else if (e > ce) {
            out.back().size = e - out.back().addr;
        }
    }

    return out;
}

static std::vector<Interval> xn_subtract(std::vector<Interval> bases, std::vector<Interval> subs) {
    bases = xn_normalize(bases);
    subs = xn_normalize(subs);

    std::vector<Interval> out;
    for (auto b : bases) {
        uint64_t cur = b.addr;
        uint64_t end = xn_end(cur, b.size);
        if (cur >= end) continue;

        for (const auto &s : subs) {
            uint64_t se = xn_end(s.addr, s.size);
            if (s.addr >= end) break;
            if (se <= cur) continue;

            if (s.addr > cur) {
                uint64_t nend = std::min(s.addr, end);
                if (nend > cur) out.push_back({cur, nend - cur});
            }

            if (se > cur) cur = se;
            if (cur >= end) break;
        }

        if (cur < end) out.push_back({cur, end - cur});
    }

    return xn_normalize(out);
}

static bool xn_merge_prot(std::vector<ProtRange> &v) {
    std::sort(v.begin(), v.end(), [](const ProtRange &a, const ProtRange &b) {
        if (a.addr != b.addr) return a.addr < b.addr;
        if (a.size != b.size) return a.size < b.size;
        return a.foff < b.foff;
    });

    std::vector<ProtRange> out;
    for (auto x : v) {
        if (x.size == 0) continue;

        if (out.empty()) {
            out.push_back(x);
            continue;
        }

        uint64_t end = xn_end(out.back().addr, out.back().size);
        uint64_t fend = xn_end(out.back().foff, out.back().size);
        if (end == ~0ULL || fend == ~0ULL) return false;
        if (x.addr < end) return false;

        if (x.prot == out.back().prot && x.addr == end && x.foff == fend) {
            if (out.back().size > ~0ULL - x.size) return false;
            uint64_t ns = out.back().size + x.size;
            if (xn_end(out.back().addr, ns) == ~0ULL) return false;
            if (xn_end(out.back().foff, ns) == ~0ULL) return false;
            out.back().size = ns;
        } else {
            out.push_back(x);
        }
    }

    v.swap(out);
    return true;
}

static uint32_t xn_rotl(uint32_t v, int n) {
    return (v << n) | (v >> (32 - n));
}

static void xn_qr(uint32_t *x, int a, int b, int c, int d) {
    x[a] += x[b]; x[d] = xn_rotl(x[d] ^ x[a], 16);
    x[c] += x[d]; x[b] = xn_rotl(x[b] ^ x[c], 12);
    x[a] += x[b]; x[d] = xn_rotl(x[d] ^ x[a], 8);
    x[c] += x[d]; x[b] = xn_rotl(x[b] ^ x[c], 7);
}

static void xn_chacha_block(const uint32_t key[8], uint32_t counter, uint32_t n0, uint32_t n1, uint32_t n2, uint8_t out[64]) {
    const uint32_t init[16] = {
        0x61707865u, 0x3320646eu, 0x79622d32u, 0x6b206574u,
        key[0], key[1], key[2], key[3], key[4], key[5], key[6], key[7],
        counter, n0, n1, n2
    };
    uint32_t x[16];
    std::memcpy(x, init, sizeof(x));
    for (int r = 0; r < 10; ++r) {
        xn_qr(x, 0, 4, 8, 12);
        xn_qr(x, 1, 5, 9, 13);
        xn_qr(x, 2, 6, 10, 14);
        xn_qr(x, 3, 7, 11, 15);
        xn_qr(x, 0, 5, 10, 15);
        xn_qr(x, 1, 6, 11, 12);
        xn_qr(x, 2, 7, 8, 13);
        xn_qr(x, 3, 4, 9, 14);
    }
    for (int i = 0; i < 16; ++i) {
        uint32_t v = x[i] + init[i];
        out[4 * i + 0] = (uint8_t)(v);
        out[4 * i + 1] = (uint8_t)(v >> 8);
        out[4 * i + 2] = (uint8_t)(v >> 16);
        out[4 * i + 3] = (uint8_t)(v >> 24);
    }
}

static void xn_crypt(uint8_t *p, uint64_t size, const uint32_t key[8], uint64_t vaddr, uint64_t rsize) {
    uint32_t n0 = (uint32_t)vaddr;
    uint32_t n1 = (uint32_t)(vaddr >> 32);
    uint32_t n2 = (uint32_t)rsize;
    uint8_t ks[64];

    for (uint64_t blk = 0; size > 0; ++blk) {
        xn_chacha_block(key, (uint32_t)blk, n0, n1, n2, ks);
        uint64_t n = size < 64 ? size : 64;
        for (uint64_t j = 0; j < n; ++j) p[j] ^= ks[j];
        p += n;
        size -= n;
    }
}

static std::string xn_base_name(const std::string &p) {
    size_t n = p.find_last_of('/');
    if (n == std::string::npos) return p;
    return p.substr(n + 1);
}

static uint64_t xn_v2o(const std::vector<Elf64_Phdr> &phdrs, uint64_t v, uint64_t need) {
    for (const auto &p : phdrs) {
        if (p.p_type != PT_LOAD || p.p_filesz == 0) continue;
        if (v < p.p_vaddr) continue;
        uint64_t delta = v - p.p_vaddr;
        if (delta >= p.p_filesz) continue;
        if (need > p.p_filesz - delta) return ~0ULL;
        return p.p_offset + delta;
    }
    return ~0ULL;
}

template <typename T>
static bool xn_read(const std::vector<uint8_t> &data, uint64_t off, T &out) {
    if (off > data.size() || sizeof(T) > data.size() - off) return false;
    std::memcpy(&out, data.data() + off, sizeof(T));
    return true;
}

int main(int argc, char **argv) {
    if (argc < 4 || std::strcmp(argv[1], "-pso") != 0) {
        std::printf("XNebula Protector\nusage: xnebula -pso <file.so>\n");
        return 1;
    }

    std::string in_path = argv[2];
    const std::string seed_path = argv[3];
    FILE *fp = std::fopen(in_path.c_str(), "rb");
    if (!fp) xn_fail("cannot open input file");

    std::fseek(fp, 0, SEEK_END);
    long fs = std::ftell(fp);
    std::fseek(fp, 0, SEEK_SET);
    if (fs <= 0) xn_fail("input file is empty");

    size_t fsize = (size_t)fs;
    std::vector<uint8_t> data(fsize);
    if (std::fread(data.data(), 1, fsize, fp) != fsize) xn_fail("cannot read input file");
    std::fclose(fp);

    if (fsize < sizeof(Elf64_Ehdr)) xn_fail("file too small");

    Elf64_Ehdr ehdr;
    std::memcpy(&ehdr, data.data(), sizeof(ehdr));

    if (ehdr.e_ident[EI_MAG0] != ELFMAG0 ||
        ehdr.e_ident[EI_MAG1] != ELFMAG1 ||
        ehdr.e_ident[EI_MAG2] != ELFMAG2 ||
        ehdr.e_ident[EI_MAG3] != ELFMAG3)
        xn_fail("not ELF");

    if (ehdr.e_ident[EI_CLASS] != ELFCLASS64 ||
        ehdr.e_ident[EI_DATA] != ELFDATA2LSB ||
        ehdr.e_type != ET_DYN ||
        (ehdr.e_machine != EM_X86_64 && ehdr.e_machine != EM_AARCH64))
        xn_fail("only ELF64 LSB x86_64 or AArch64 ET_DYN .so supported");

    if (ehdr.e_phoff == 0 || ehdr.e_phnum == 0 || ehdr.e_phentsize != sizeof(Elf64_Phdr))
        xn_fail("bad program header table");

    const bool is_a64 = ehdr.e_machine == EM_AARCH64;
    if (is_a64) xn_fail("AArch64 stub is not yet migrated to the signed format");
    const uint8_t *stub_s = is_a64 ? xn_a64_stub : xn_stub_start;
    const uint8_t *code_e = is_a64 ? xn_a64_stub + XN_A64_CODE_LEN : xn_code_end;
    const uint8_t *cfg_s = is_a64 ? xn_a64_stub + XN_A64_CODE_LEN : xn_cfg_start;
    const uint8_t *stub_e = is_a64 ? xn_a64_stub + sizeof(xn_a64_stub) : xn_stub_end;
    const uint64_t irel_type = is_a64 ? (uint64_t)R_AARCH64_IRELATIVE : (uint64_t)R_X86_64_IRELATIVE;

    uint64_t file_size = (uint64_t)data.size();
    uint64_t ph_size = (uint64_t)ehdr.e_phnum * ehdr.e_phentsize;
    if (ehdr.e_phoff > file_size || ph_size > file_size - ehdr.e_phoff)
        xn_fail("program header table truncated");

    std::vector<Elf64_Phdr> phdrs(ehdr.e_phnum);
    std::memcpy(phdrs.data(), data.data() + ehdr.e_phoff, ph_size);

    int dyn_idx = -1;
    int phdr_idx = -1;
    uint64_t max_load = 0;
    uint64_t min_load = ~0ULL;

    for (uint16_t i = 0; i < ehdr.e_phnum; ++i) {
        const Elf64_Phdr &p = phdrs[i];

        if (p.p_type == PT_PHDR && phdr_idx < 0)
            phdr_idx = i;

        if (p.p_type == PT_LOAD) {
            if (p.p_memsz < p.p_filesz)
                xn_fail("bad PT_LOAD memsz");

            uint64_t mem_end = xn_end(p.p_vaddr, p.p_memsz);
            if (mem_end == ~0ULL)
                xn_fail("PT_LOAD virtual range overflow");

            if (p.p_filesz) {
                uint64_t file_end = xn_end(p.p_offset, p.p_filesz);
                if (file_end == ~0ULL || file_end > file_size)
                    xn_fail("PT_LOAD file range truncated");

                uint64_t vfile_end = xn_end(p.p_vaddr, p.p_filesz);
                if (vfile_end == ~0ULL)
                    xn_fail("PT_LOAD virtual file range overflow");
            }

            if (mem_end > max_load) max_load = mem_end;
            if (p.p_vaddr < min_load) min_load = p.p_vaddr;
        }

        if (p.p_type == PT_DYNAMIC && dyn_idx < 0)
            dyn_idx = i;
    }

    if (dyn_idx < 0) xn_fail("no PT_DYNAMIC");
    if (max_load == 0) xn_fail("no PT_LOAD");

    Elf64_Phdr dynph = phdrs[dyn_idx];
    if (dynph.p_filesz == 0 || (dynph.p_filesz % sizeof(Elf64_Dyn)) != 0)
        xn_fail("bad dynamic segment size");

    uint64_t dyn_file_end = xn_end(dynph.p_offset, dynph.p_filesz);
    if (dyn_file_end == ~0ULL || dyn_file_end > file_size)
        xn_fail("dynamic segment truncated");

    auto need_off = [&](uint64_t v, uint64_t n) -> uint64_t {
        uint64_t o = xn_v2o(phdrs, v, n);
        if (o == ~0ULL) xn_fail("table address is not inside a loadable segment");
        return o;
    };

    auto offset_to_vaddr = [&](uint64_t off, uint64_t &v) -> bool {
        for (const auto &p : phdrs) {
            if (p.p_type != PT_LOAD || p.p_filesz == 0) continue;
            uint64_t begin = p.p_offset;
            uint64_t end = xn_end(begin, p.p_filesz);
            if (end == ~0ULL) continue;
            if (off >= begin && off < end) {
                uint64_t delta = off - begin;
                if (p.p_vaddr > ~0ULL - delta) return false;
                v = p.p_vaddr + delta;
                return true;
            }
        }
        return false;
    };

    std::vector<Elf64_Dyn> origdyn;
    uint64_t dcount = dynph.p_filesz / sizeof(Elf64_Dyn);
    for (uint64_t i = 0; i < dcount; ++i) {
        Elf64_Dyn d;
        std::memcpy(&d, data.data() + dynph.p_offset + i * sizeof(Elf64_Dyn), sizeof(d));
        origdyn.push_back(d);
        if (d.d_tag == DT_NULL) break;
    }

    if (origdyn.empty()) xn_fail("dynamic table empty");

    std::map<uint64_t, uint64_t> dv;
    for (const auto &d : origdyn) {
        if ((uint64_t)d.d_tag == DT_NULL) break;
        dv.emplace((uint64_t)d.d_tag, (uint64_t)d.d_un.d_ptr);
    }

    auto dget = [&](uint64_t tag) -> uint64_t {
        auto it = dv.find(tag);
        return it == dv.end() ? 0 : it->second;
    };

    const uint64_t original_init = dget(DT_INIT);
    const uint64_t strtab = dget(DT_STRTAB);
    const uint64_t strsz = dget(DT_STRSZ);
    const uint64_t symtab = dget(DT_SYMTAB);
    const uint64_t hash = dget(DT_HASH);
    const uint64_t gnu_hash = dget(DT_GNU_HASH);
    const uint64_t rela = dget(DT_RELA);
    const uint64_t relasz = dget(DT_RELASZ);
    const uint64_t rel = dget(DT_REL);
    const uint64_t relsz = dget(DT_RELSZ);
    const uint64_t jmprel = dget(DT_JMPREL);
    const uint64_t pltrelsz = dget(DT_PLTRELSZ);
    const uint64_t pltrel = dget(DT_PLTREL);
    const uint64_t initarr = dget(DT_INIT_ARRAY);
    const uint64_t initarrsz = dget(DT_INIT_ARRAYSZ);
    const uint64_t finiarr = dget(DT_FINI_ARRAY);
    const uint64_t finiarrsz = dget(DT_FINI_ARRAYSZ);
    const uint64_t preinit = dget(DT_PREINIT_ARRAY);
    const uint64_t preinitsz = dget(DT_PREINIT_ARRAYSZ);
    const uint64_t versym = dget(DT_VERSYM);
    const uint64_t verdef = dget(DT_VERDEF);
    const uint64_t verdefnum = dget(DT_VERDEFNUM);
    const uint64_t verneed = dget(DT_VERNEED);
    const uint64_t verneednum = dget(DT_VERNEEDNUM);
    const uint64_t pltgot = dget(DT_PLTGOT);
    const uint64_t symtab_shndx = dget(XN_DT_SYMTAB_SHNDX);
    const uint64_t relr = dget(XN_DT_RELR);
    const uint64_t relrsz = dget(XN_DT_RELRSZ);

    if (relr && !relrsz) xn_fail("DT_RELR without DT_RELRSZ");

    const uint64_t plt_ent = (pltrel == DT_REL) ? sizeof(Elf64_Rel) : sizeof(Elf64_Rela);

    uint64_t symcount = 0;
    bool have_count = false;
    uint64_t hash_size = 0;
    uint64_t gnu_size = 0;

    if (hash) {
        uint64_t off = need_off(hash, 8);
        uint32_t nb = 0, nc = 0;
        if (!xn_read(data, off, nb) || !xn_read(data, off + 4, nc))
            xn_fail("bad DT_HASH table");
        hash_size = 8ULL + 4ULL * nb + 4ULL * nc;
        (void)need_off(hash, hash_size);
        symcount = nc;
        have_count = true;
    }

    if (gnu_hash) {
        uint64_t goff = need_off(gnu_hash, 16);
        uint32_t nb = 0, so = 0, bs = 0;
        if (!xn_read(data, goff, nb) || !xn_read(data, goff + 4, so) ||
            !xn_read(data, goff + 8, bs) || nb == 0)
            xn_fail("bad DT_GNU_HASH table");

        uint64_t buckets_off = goff + 16ULL + 8ULL * bs;
        uint64_t chains_off = buckets_off + 4ULL * nb;
        if (chains_off > file_size) xn_fail("bad DT_GNU_HASH table");

        uint32_t maxb = 0;
        for (uint32_t b = 0; b < nb; ++b) {
            uint32_t v = 0;
            if (!xn_read(data, buckets_off + 4ULL * b, v)) xn_fail("bad DT_GNU_HASH table");
            if (v > maxb) maxb = v;
        }

        uint64_t count = so;
        uint64_t chain_n = 0;
        if (maxb >= so) {
            uint64_t idx = maxb;
            for (;;) {
                uint32_t cv = 0;
                if (!xn_read(data, chains_off + 4ULL * (idx - so), cv))
                    xn_fail("bad DT_GNU_HASH chain");
                if (cv & 1) break;
                ++idx;
            }
            count = idx + 1;
            chain_n = count - so;
        }

        gnu_size = 16ULL + 8ULL * bs + 4ULL * nb + 4ULL * chain_n;
        (void)need_off(gnu_hash, gnu_size);
        if (!have_count) {
            symcount = count;
            have_count = true;
        }
    }

    if (!have_count && ehdr.e_shoff && ehdr.e_shentsize == sizeof(Elf64_Shdr)) {
        for (uint64_t i = 0; i < ehdr.e_shnum && !have_count; ++i) {
            Elf64_Shdr sh;
            if (!xn_read(data, ehdr.e_shoff + i * sizeof(Elf64_Shdr), sh)) break;
            if (sh.sh_type == SHT_DYNSYM && sh.sh_entsize == sizeof(Elf64_Sym)) {
                symcount = sh.sh_size / sizeof(Elf64_Sym);
                have_count = true;
            }
        }
    }

    if (!have_count) xn_fail("cannot determine .dynsym size");
    if (symcount > file_size / sizeof(Elf64_Sym)) xn_fail("bad dynamic symbol count");

    uint64_t verdef_size = 0;
    if (verdef) {
        if (!verdefnum) xn_fail("DT_VERDEF without DT_VERDEFNUM");
        uint64_t start = need_off(verdef, sizeof(Elf64_Verdef));
        uint64_t off = start;
        uint64_t end = start;
        for (uint64_t i = 0; i < verdefnum; ++i) {
            Elf64_Verdef vd;
            if (!xn_read(data, off, vd)) xn_fail("bad version definition table");
            end = std::max(end, off + sizeof(vd));
            uint64_t aoff = off + vd.vd_aux;
            for (uint64_t k = 0; k < vd.vd_cnt; ++k) {
                Elf64_Verdaux va;
                if (!xn_read(data, aoff, va)) xn_fail("bad version definition table");
                end = std::max(end, aoff + sizeof(va));
                if (!va.vda_next) break;
                aoff += va.vda_next;
            }
            if (!vd.vd_next) break;
            off += vd.vd_next;
        }
        verdef_size = end - start;
        (void)need_off(verdef, verdef_size);
    }

    uint64_t verneed_size = 0;
    if (verneed) {
        if (!verneednum) xn_fail("DT_VERNEED without DT_VERNEEDNUM");
        uint64_t start = need_off(verneed, sizeof(Elf64_Verneed));
        uint64_t off = start;
        uint64_t end = start;
        for (uint64_t i = 0; i < verneednum; ++i) {
            Elf64_Verneed vn;
            if (!xn_read(data, off, vn)) xn_fail("bad version needed table");
            end = std::max(end, off + sizeof(vn));
            uint64_t aoff = off + vn.vn_aux;
            for (uint64_t k = 0; k < vn.vn_cnt; ++k) {
                Elf64_Vernaux va;
                if (!xn_read(data, aoff, va)) xn_fail("bad version needed table");
                end = std::max(end, aoff + sizeof(va));
                if (!va.vna_next) break;
                aoff += va.vna_next;
            }
            if (!vn.vn_next) break;
            off += vn.vn_next;
        }
        verneed_size = end - start;
        (void)need_off(verneed, verneed_size);
    }

    std::vector<Interval> excludes;

    auto add_excl = [&](uint64_t addr, uint64_t size) {
        if (!addr || !size) return;
        if (size > ~0ULL - addr) size = ~0ULL - addr;
        excludes.push_back({addr, size});
    };

    auto add_excl_at = [&](uint64_t addr, uint64_t size) {
        if (!size) return;
        if (size > ~0ULL - addr) size = ~0ULL - addr;
        excludes.push_back({addr, size});
    };

    auto scan_relocs = [&](uint64_t addr, uint64_t size, uint64_t entsz) {
        if (!addr || !size) return;
        if (size % entsz) xn_fail("relocation table size is not a multiple of its entry size");
        uint64_t off = need_off(addr, size);
        for (uint64_t o = 0; o < size; o += entsz) {
            uint64_t r_offset = 0, r_info = 0;
            std::memcpy(&r_offset, data.data() + off + o, 8);
            std::memcpy(&r_info, data.data() + off + o + 8, 8);
            if ((r_info & 0xffffffffULL) == irel_type)
                xn_fail("IRELATIVE relocations (IFUNC) are not supported: resolvers run before DT_INIT");
            add_excl_at(r_offset, 8);
        }
    };

    if (symcount && symtab) {
        uint64_t soff = need_off(symtab, symcount * sizeof(Elf64_Sym));
        for (uint64_t i = 0; i < symcount; ++i) {
            uint8_t info = data[soff + i * sizeof(Elf64_Sym) + 4];
            if (ELF64_ST_TYPE(info) == STT_GNU_IFUNC)
                xn_fail("IFUNC symbols are not supported: resolvers run before DT_INIT");
        }
    }

    if (min_load != ~0ULL)
        add_excl_at(align_down(min_load, 4096), 4096);

    uint64_t mapped_vaddr = 0;
    if (offset_to_vaddr(0, mapped_vaddr))
        add_excl_at(mapped_vaddr, sizeof(Elf64_Ehdr));

    if (ehdr.e_phoff && offset_to_vaddr(ehdr.e_phoff, mapped_vaddr))
        add_excl_at(mapped_vaddr, ph_size);

    if (ehdr.e_shoff && ehdr.e_shnum && ehdr.e_shentsize) {
        if (ehdr.e_shnum <= UINT64_MAX / ehdr.e_shentsize) {
            uint64_t shsz = (uint64_t)ehdr.e_shnum * ehdr.e_shentsize;
            uint64_t shend = xn_end(ehdr.e_shoff, shsz);
            if (shend != ~0ULL && shend <= file_size) {
                if (offset_to_vaddr(ehdr.e_shoff, mapped_vaddr))
                    add_excl_at(mapped_vaddr, shsz);
            }
        }
    }

    for (const auto &p : phdrs) {
        if (p.p_type == PT_LOAD || p.p_type == PT_NULL) continue;
        if (p.p_type == PT_GNU_RELRO && p.p_memsz) {
            uint64_t rs = align_down(p.p_vaddr, 4096);
            uint64_t re_raw = xn_end(p.p_vaddr, p.p_memsz);
            uint64_t re = re_raw == ~0ULL ? ~0ULL : align_up(re_raw, 4096);
            if (re != ~0ULL && re > rs) add_excl_at(rs, re - rs);
        }
        if (p.p_filesz)
            add_excl(p.p_vaddr, p.p_filesz);
    }

    add_excl(dynph.p_vaddr, dynph.p_filesz);
    add_excl(strtab, strsz);
    add_excl(symtab, symcount * sizeof(Elf64_Sym));
    add_excl(hash, hash_size);
    add_excl(gnu_hash, gnu_size);
    add_excl(rela, relasz);
    add_excl(rel, relsz);
    add_excl(jmprel, pltrelsz);
    scan_relocs(rela, relasz, sizeof(Elf64_Rela));
    scan_relocs(rel, relsz, sizeof(Elf64_Rel));
    scan_relocs(jmprel, pltrelsz, plt_ent);
    add_excl(initarr, initarrsz);
    add_excl(finiarr, finiarrsz);
    add_excl(preinit, preinitsz);
    add_excl(relr, relrsz);
    add_excl(symtab_shndx, symcount * sizeof(uint32_t));
    add_excl(versym, symcount * sizeof(uint16_t));
    add_excl(verdef, verdef_size);
    add_excl(verneed, verneed_size);
    add_excl(pltgot, 8ULL * (3ULL + (plt_ent ? pltrelsz / plt_ent : 0ULL)));

    std::vector<ProtRange> ranges;

    for (const auto &p : phdrs) {
        if (p.p_type != PT_LOAD || p.p_filesz == 0)
            continue;

        std::vector<Interval> base;
        base.push_back({p.p_vaddr, p.p_filesz});

        auto kept = xn_subtract(base, excludes);

        uint64_t prot = 0;
        if (p.p_flags & PF_R) prot |= 1;
        if (p.p_flags & PF_W) prot |= 2;
        if (p.p_flags & PF_X) prot |= 4;

        for (auto r : kept) {
            if (!r.size) continue;
            if (r.addr < p.p_vaddr) continue;

            uint64_t vend = xn_end(p.p_vaddr, p.p_filesz);
            if (vend == ~0ULL || r.addr >= vend) continue;

            uint64_t delta = r.addr - p.p_vaddr;
            if (delta > p.p_filesz) continue;
            if (p.p_offset > ~0ULL - delta) continue;

            uint64_t off = p.p_offset + delta;
            if (off > file_size || r.size > file_size - off)
                xn_fail("encryption range out of file");

            ranges.push_back({r.addr, r.size, prot, off});
        }
    }

    if (ranges.empty())
        xn_fail("no loadable data outside the first page to protect (link with -z separate-code)");

    if (!xn_merge_prot(ranges))
        xn_fail("invalid protected ranges");

    if (ranges.size() > 65536)
        xn_fail("too many protected ranges");

    for (auto &r : ranges) {
        if (r.size >= (1ULL << 36))
            xn_fail("range too large");
    }

    std::vector<ProtRange> file_check = ranges;
    std::sort(file_check.begin(), file_check.end(), [](const ProtRange &a, const ProtRange &b) {
        return a.foff < b.foff;
    });

    uint64_t file_prev_end = 0;
    for (const auto &r : file_check) {
        if (r.foff < file_prev_end)
            xn_fail("overlapping encryption ranges in file");
        uint64_t e = xn_end(r.foff, r.size);
        if (e == ~0ULL)
            xn_fail("encryption range overflow");
        file_prev_end = e;
    }

    const uint64_t stub_len = (uint64_t)(reinterpret_cast<uintptr_t>(stub_e) - reinterpret_cast<uintptr_t>(stub_s));
    const uint64_t code_len = (uint64_t)(reinterpret_cast<uintptr_t>(code_e) - reinterpret_cast<uintptr_t>(stub_s));
    const uint64_t cfg_off = (uint64_t)(reinterpret_cast<uintptr_t>(cfg_s) - reinterpret_cast<uintptr_t>(stub_s));
    if (code_len == 0 || cfg_off + XN_CFG_HDR != stub_len)
        xn_fail("stub layout mismatch");

    unsigned char stub_digest[64];
    crypto_hash_sha512(stub_digest, stub_s, code_len);
    unsigned char seed[32], sign_pk[32], sign_sk[64];
    {
        FILE *sf = std::fopen(seed_path.c_str(), "rb");
        if (!sf || std::fread(seed, 1, 32, sf) != 32) xn_fail("cannot read 32-byte signing seed");
        std::fclose(sf);
        crypto_sign_seed_keypair(sign_pk, sign_sk, seed);
    }

    uint8_t keybytes[32];
    int ufd = open("/dev/urandom", O_RDONLY);
    if (ufd < 0) xn_fail("cannot open /dev/urandom");
    ssize_t got = 0;
    while (got < (ssize_t)sizeof(keybytes)) {
        ssize_t rr = read(ufd, keybytes + got, sizeof(keybytes) - got);
        if (rr <= 0) break;
        got += rr;
    }
    close(ufd);
    if (got != (ssize_t)sizeof(keybytes)) xn_fail("cannot read random key");

    uint32_t kw[8];
    for (int i = 0; i < 8; ++i) {
        kw[i] = (uint32_t)keybytes[4 * i] |
                ((uint32_t)keybytes[4 * i + 1] << 8) |
                ((uint32_t)keybytes[4 * i + 2] << 16) |
                ((uint32_t)keybytes[4 * i + 3] << 24);
    }

    uint64_t stored_key[4];
    for (uint64_t i = 0; i < 4; ++i) {
        uint64_t kq = 0;
        for (int b = 7; b >= 0; --b)
            kq = (kq << 8) | keybytes[8 * i + (uint64_t)b];
        uint64_t dig = 0;
        for (int b = 7; b >= 0; --b)
            dig = (dig << 8) | stub_digest[8 * i + (uint64_t)b];
        stored_key[i] = kq ^ dig;
    }

    for (auto &r : ranges) {
        if (r.foff > file_size || r.size > file_size - r.foff)
            xn_fail("encryption range out of file");

        crypto_hash_sha512(r.digest, data.data() + r.foff, r.size);
        xn_crypt(data.data() + r.foff, r.size, kw, r.addr, r.size);
    }

    uint64_t entry_bytes = ranges.size() * XN_ENTRY;
    if (entry_bytes > UINT64_MAX - stub_len)
        xn_fail("configuration overflow");

    uint64_t config_end = stub_len + entry_bytes + XN_SIG;
    uint64_t dyn_offset = align_up(config_end, 4096);
    if (dyn_offset == ~0ULL)
        xn_fail("layout overflow");

    uint64_t seg_vaddr = align_up(max_load, 4096);
    if (seg_vaddr == ~0ULL || seg_vaddr == 0 || seg_vaddr < max_load)
        xn_fail("cannot allocate new segment");

    std::vector<Elf64_Dyn> newdyn;
    bool init_set = false;

    for (auto d : origdyn) {
        uint64_t tag = (uint64_t)d.d_tag;
        if (tag == DT_NULL) break;

        if (tag == DT_INIT) {
            if (!init_set) {
                d.d_un.d_ptr = seg_vaddr;
                init_set = true;
                newdyn.push_back(d);
            }
            continue;
        }

        newdyn.push_back(d);
    }

    if (!init_set) {
        Elf64_Dyn d{};
        d.d_tag = DT_INIT;
        d.d_un.d_ptr = seg_vaddr;
        newdyn.push_back(d);
    }

    Elf64_Dyn nul{};
    nul.d_tag = DT_NULL;
    nul.d_un.d_val = 0;
    newdyn.push_back(nul);

    if (newdyn.size() > UINT64_MAX / sizeof(Elf64_Dyn))
        xn_fail("dynamic table overflow");

    uint64_t dyn_bytes = newdyn.size() * sizeof(Elf64_Dyn);
    if (dyn_offset > UINT64_MAX - dyn_bytes)
        xn_fail("layout overflow");

    uint64_t dyn_end_layout = dyn_offset + dyn_bytes;
    uint64_t phdr_offset = align_up(dyn_end_layout, 16);
    if (phdr_offset == ~0ULL)
        xn_fail("layout overflow");

    uint64_t new_phnum = (uint64_t)ehdr.e_phnum + 1;
    if (new_phnum > 65535)
        xn_fail("too many program headers");

    if (new_phnum > UINT64_MAX / sizeof(Elf64_Phdr))
        xn_fail("program header table overflow");

    uint64_t phdr_bytes = new_phnum * sizeof(Elf64_Phdr);
    if (phdr_offset > UINT64_MAX - phdr_bytes)
        xn_fail("layout overflow");

    uint64_t total_end = phdr_offset + phdr_bytes;
    uint64_t total_size = align_up(total_end, 16);
    if (total_size == ~0ULL)
        xn_fail("layout overflow");

    uint64_t seg_offset = align_up(file_size, 4096);
    if (seg_offset == ~0ULL)
        xn_fail("file offset overflow");

    if (seg_offset > UINT64_MAX - total_size)
        xn_fail("file offset overflow");

    uint64_t final_file_size = seg_offset + total_size;
    if (final_file_size > (uint64_t)std::numeric_limits<size_t>::max())
        xn_fail("output file too large");

    if (seg_vaddr > UINT64_MAX - total_size)
        xn_fail("virtual address overflow");

    if (seg_offset > UINT64_MAX - phdr_offset)
        xn_fail("file offset overflow");

    uint64_t new_phoff = seg_offset + phdr_offset;

    Elf64_Ehdr out_ehdr = ehdr;
    out_ehdr.e_phoff = new_phoff;
    out_ehdr.e_phnum = (uint16_t)new_phnum;

    if (ehdr.e_shoff && ehdr.e_shnum && ehdr.e_shentsize == sizeof(Elf64_Shdr)) {
        uint64_t sh_bytes = (uint64_t)ehdr.e_shnum * sizeof(Elf64_Shdr);
        uint64_t sh_end = xn_end(ehdr.e_shoff, sh_bytes);
        if (sh_end == ~0ULL || sh_end > file_size)
            xn_fail("section table truncated");

        uint64_t tmp_v = 0;
        const bool sh_mapped = offset_to_vaddr(ehdr.e_shoff, tmp_v);

        for (uint64_t i = 0; i < ehdr.e_shnum; ++i) {
            Elf64_Shdr sh;
            std::memcpy(&sh, data.data() + ehdr.e_shoff + i * sizeof(Elf64_Shdr), sizeof(sh));
            if ((sh.sh_flags & SHF_ALLOC) || sh.sh_type == SHT_NOBITS || sh.sh_type == SHT_NULL)
                continue;
            if (sh.sh_size == 0) continue;
            if (sh.sh_offset > file_size || sh.sh_size > file_size - sh.sh_offset)
                xn_fail("section data truncated");
            uint64_t tmp_s = 0;
            if (offset_to_vaddr(sh.sh_offset, tmp_s)) continue;
            std::memset(data.data() + sh.sh_offset, 0, (size_t)sh.sh_size);
        }

        if (!sh_mapped)
            std::memset(data.data() + ehdr.e_shoff, 0, (size_t)sh_bytes);

        out_ehdr.e_shoff = 0;
        out_ehdr.e_shnum = 0;
        out_ehdr.e_shstrndx = 0;
    }

    std::memcpy(data.data(), &out_ehdr, sizeof(out_ehdr));

    data.resize((size_t)final_file_size, 0);

    std::memcpy(data.data() + seg_offset, stub_s, (size_t)stub_len);

    const uint64_t cfg_base = seg_offset + cfg_off;
    auto put64 = [&](uint64_t abs_off, uint64_t v) {
        std::memcpy(data.data() + abs_off, &v, 8);
    };

    put64(cfg_base + 0, XN_MAGIC);
    put64(cfg_base + 8, seg_vaddr);
    put64(cfg_base + 16, original_init);
    put64(cfg_base + 24, (uint64_t)ranges.size());
    for (uint64_t i = 0; i < 4; ++i)
        put64(cfg_base + 32 + 8 * i, stored_key[i]);

    std::memcpy(data.data() + cfg_base + 64, sign_pk, 32);
    uint64_t ent = seg_offset + stub_len;
    for (const auto &r : ranges) {
        uint64_t packed = r.size | ((r.prot & 0xff) << 56);
        put64(ent + 0, r.addr);
        put64(ent + 8, packed);
        std::memcpy(data.data() + ent + 16, r.digest, 64);
        ent += XN_ENTRY;
    }

    {
        const uint64_t manifest_len = XN_CFG_HDR + (uint64_t)ranges.size() * XN_ENTRY;
        uint8_t mdig[64];
        crypto_hash_sha512(mdig, data.data() + cfg_base, manifest_len);
        unsigned long long siglen = 0;
        crypto_sign_detached(data.data() + cfg_base + manifest_len, &siglen, mdig, 64, sign_sk);
    }
    std::memcpy(data.data() + seg_offset + dyn_offset, newdyn.data(), (size_t)dyn_bytes);

    std::vector<Elf64_Phdr> out_phdrs = phdrs;

    Elf64_Phdr &dynout = out_phdrs[dyn_idx];
    dynout.p_type = PT_DYNAMIC;
    dynout.p_flags = PF_R;
    dynout.p_offset = seg_offset + dyn_offset;
    dynout.p_vaddr = seg_vaddr + dyn_offset;
    dynout.p_paddr = seg_vaddr + dyn_offset;
    dynout.p_filesz = dyn_bytes;
    dynout.p_memsz = dyn_bytes;
    dynout.p_align = 8;

    if (phdr_idx >= 0) {
        Elf64_Phdr &phout = out_phdrs[phdr_idx];
        phout.p_type = PT_PHDR;
        phout.p_flags = PF_R;
        phout.p_offset = seg_offset + phdr_offset;
        phout.p_vaddr = seg_vaddr + phdr_offset;
        phout.p_paddr = seg_vaddr + phdr_offset;
        phout.p_filesz = phdr_bytes;
        phout.p_memsz = phdr_bytes;
        phout.p_align = 8;
    }

    Elf64_Phdr newload{};
    newload.p_type = PT_LOAD;
    newload.p_flags = PF_R | PF_X;
    newload.p_offset = seg_offset;
    newload.p_vaddr = seg_vaddr;
    newload.p_paddr = seg_vaddr;
    newload.p_filesz = total_size;
    newload.p_memsz = total_size;
    newload.p_align = 4096;
    out_phdrs.push_back(newload);

    if (out_phdrs.size() != (size_t)new_phnum)
        xn_fail("program header table mismatch");

    std::memcpy(data.data() + seg_offset + phdr_offset, out_phdrs.data(), (size_t)phdr_bytes);

    std::string out_path = xn_base_name(in_path) + ".xn.so";
    FILE *of = std::fopen(out_path.c_str(), "wb");
    if (!of) xn_fail("cannot create output file");

    if (std::fwrite(data.data(), 1, data.size(), of) != data.size()) {
        std::fclose(of);
        xn_fail("cannot write output file");
    }

    std::fclose(of);
    chmod(out_path.c_str(), 0755);

    std::printf("XNebula patch created: %s\n", out_path.c_str());
    return 0;
}