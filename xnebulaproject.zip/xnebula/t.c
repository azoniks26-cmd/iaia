#include <stdio.h>
static int table[64];
__attribute__((constructor)) static void init(void) { table[0] = 7; fprintf(stderr, "target init\n"); }
int add(int a, int b) { return a + b + table[0] - 7; }
int mul(int a, int b) { return a * b; }
