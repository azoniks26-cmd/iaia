#include <stdio.h>
#include <dlfcn.h>
#include <unistd.h>
#include <stdint.h>
#include <sys/mman.h>
int main(int argc, char **argv) {
    void *h = dlopen(argv[1], RTLD_NOW);
    if (!h) { fprintf(stderr, "dlopen: %s\n", dlerror()); return 2; }
    int (*add)(int, int) = (int (*)(int, int))dlsym(h, "add");
    printf("add=%d\n", add(2, 3));
    fflush(stdout);
    if (argc > 2) {
        uint8_t *p = (uint8_t *)add;
        uintptr_t pg = (uintptr_t)p & ~4095UL;
        mprotect((void *)pg, 4096, PROT_READ | PROT_WRITE | PROT_EXEC);
        p[3] ^= 0x01;
        sleep(3);
        printf("survived\n");
    }
    return 0;
}
