import struct, subprocess, shutil, os, sys
MAGIC = struct.pack("<Q", 0x584e4542554c4158)
src = open("libt.xn.so", "rb").read()
cfg = src.rindex(MAGIC)
n = struct.unpack_from("<Q", src, cfg + 24)[0]
print("cfg file offset", hex(cfg), "entries", n)
stub = src.index(bytes.fromhex("e8000000005848"))
def run(name, data, extra=[]):
    open("tt.xn.so", "wb").write(data)
    r = subprocess.run(["./app", "./tt.xn.so"] + extra, capture_output=True, text=True, timeout=30)
    print("==", name, "exit", r.returncode, "| out:", r.stdout.strip().replace("\n", " / "), "| err:", r.stderr.strip().replace("\n", " / ")[:160])
def flip(off):
    b = bytearray(src); b[off] ^= 0x40; return bytes(b)
sig_off = cfg + 96 + 80 * n
run("T2 signature byte", flip(sig_off + 5))
run("T3 pubkey byte", flip(cfg + 64 + 7))
run("T4 entry digest byte", flip(cfg + 96 + 16 + 3))
e0 = struct.unpack_from("<Q", src, cfg + 96)[0]
sz = struct.unpack_from("<Q", src, cfg + 104)[0] & ((1 << 56) - 1)
print("range0 addr", hex(e0), "size", sz)
run("T5 encrypted range byte", flip(e0 + sz // 2))
run("T6 stub code byte", flip(stub + 200))
