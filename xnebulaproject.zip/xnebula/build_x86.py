import re

ROOT = "/home/claude/ed25519/"
orig = open("main_orig.cpp").read()

def clean_asm(path, included, seen_macros):
    out = []
    skip_macro = False
    for line in open(path).read().splitlines():
        s = line.strip()
        if s.startswith(".section .note.GNU-stack"):
            continue
        if s.startswith(".include"):
            name = s.split('"')[1]
            if name in included:
                continue
            included.add(name)
            out.append(open(ROOT + name).read())
            continue
        if s.startswith(".macro"):
            name = s.split()[1].rstrip(",")
            if name in seen_macros:
                skip_macro = True
                continue
            seen_macros.add(name)
        if skip_macro:
            if s == ".endm":
                skip_macro = False
            continue
        out.append(line)
    return "\n".join(out) + "\n"

included, macros = set(), set()
crypto = ""
for f in ["x86_64/sha512_x86_64.S", "fe/fe_x86_64.S", "pt/pt_x86_64.S", "ed/ed_x86_64.S"]:
    crypto += clean_asm(ROOT + f, included, macros)
crypto = crypto.replace(".set HB, 8", ".set HB, 8")

def rep(text, old, new, count=1):
    n = text.count(old)
    assert n == count, ("expected %d occurrence(s), found %d" % (count, n), old[:70])
    return text.replace(old, new)

def cut(text, start_marker, end_marker, new):
    assert text.count(start_marker) == 1, ("start", start_marker[:60])
    a = text.index(start_marker)
    b = text.index(end_marker, a) + len(end_marker)
    return text[:a] + new + text[b:]

t = orig

t = rep(t, "#include <sys/stat.h>\n", "#include <sys/stat.h>\n#include <sodium.h>\n")

t = rep(t, "mov $4, %edi\nxor %esi, %esi\nmov $157, %eax\nsyscall\n",
"""mov 24(%rbx), %rsi
imul $80, %rsi, %rsi
add $96, %rsi
mov %rbx, %rdi
lea 640(%rsp), %rdx
call xn_sha512
mov 24(%rbx), %rax
imul $80, %rax, %rax
lea 96(%rbx,%rax,1), %rdi
lea 64(%rbx), %rsi
lea 640(%rsp), %rdx
call xn_ed_verify
test %eax, %eax
jz .Lxn_err_sig
mov $4, %edi
xor %esi, %esi
mov $157, %eax
syscall
""")

t = cut(t, "mov 0(%rsp), %rsi\nadd 8(%rbx), %rsi\n", "cmp $4, %r15\njb .Lxn_key\n",
"""mov 0(%rsp), %rdi
add 8(%rbx), %rdi
mov $(xn_code_end - xn_stub_start), %esi
lea 704(%rsp), %rdx
call xn_sha512
.set xn_i, 0
.rept 4
mov 32+8*xn_i(%rbx), %r11
xor 704+8*xn_i(%rsp), %r11
mov %r11, 32+8*xn_i(%rsp)
.set xn_i, xn_i+1
.endr
""")

t = rep(t, "mov 24(%rsp), %rsi\nmov 0(%rsi), %r9\nmov 8(%rsi), %r10\nmov 16(%rsi), %r11\nadd $24, %rsi\nmov %rsi, 24(%rsp)\n",
"""mov 24(%rsp), %rsi
mov %rsi, 336(%rsp)
mov 0(%rsi), %r9
mov 8(%rsi), %r10
mov 16(%rsi), %r11
add $80, %rsi
mov %rsi, 24(%rsp)
""")

t = cut(t, "mov 288(%rsp), %rsi\nmov 264(%rsp), %rdi\nadd %rsi, %rdi\n", "jne .Lxn_err_integrity\n",
"""mov 288(%rsp), %rdi
mov 264(%rsp), %rsi
lea 768(%rsp), %rdx
call xn_sha512
mov 336(%rsp), %rsi
add $16, %rsi
lea 768(%rsp), %rdi
mov $64, %ecx
repe cmpsb
jne .Lxn_err_integrity
""")

t = cut(t, ".Lxn_integrity_scan:\n", ".Lxn_is_done:\nret\n",
""".Lxn_integrity_scan:
sub $64, %rsp
mov 8(%r12), %r13
mov 16(%r12), %r14
xor %r15d, %r15d
.Lxn_is_loop:
cmp %r14, %r15
jae .Lxn_is_done
imul $80, %r15, %rax
mov (%r13,%rax,1), %rdi
add (%r12), %rdi
mov 8(%r13,%rax,1), %rsi
shl $8, %rsi
shr $8, %rsi
mov %rsp, %rdx
call xn_sha512
imul $80, %r15, %rax
lea 16(%r13,%rax,1), %rsi
mov %rsp, %rdi
mov $64, %ecx
repe cmpsb
jne .Lxn_err_integrity
inc %r15
jmp .Lxn_is_loop
.Lxn_is_done:
add $64, %rsp
ret
""")

t = rep(t, ".Lxn_err_integrity:\n",
""".Lxn_err_sig:
lea .Lmsg_sig(%rip), %rsi
mov $(.Lmsg_sig_end - .Lmsg_sig), %edx
jmp .Lxn_die
.Lxn_err_integrity:
""")

t = rep(t, ".Lmsg_integ_end:\n",
""".Lmsg_integ_end:
.Lmsg_sig:
.ascii "XNebula: signature verification failed\\n"
.Lmsg_sig_end:
""")

t = rep(t, "xn_cfg_start:\n.skip 64\n", "xn_cfg_start:\n.skip 96\n")
t = rep(t, "lea 64(%rbx), %r9\nmov %r9, 24(%rsp)\n", "lea 96(%rbx), %r9\nmov %r9, 24(%rsp)\n")
t = rep(t, "lea 64(%rbx), %r9\nmov %r9, 8(%rax)\n", "lea 96(%rbx), %r9\nmov %r9, 8(%rax)\n")

t = rep(t, ".balign 16\n.globl xn_code_end\nxn_code_end:\n",
crypto + "\n.balign 16\n.globl xn_code_end\nxn_code_end:\n")

t = rep(t, "constexpr uint64_t XN_CFG_HDR = 64;\nconstexpr uint64_t XN_ENTRY = 24;\nconstexpr uint64_t XN_FNV_OFFSET = 0xcbf29ce484222325ULL;\nconstexpr uint64_t XN_FNV_PRIME = 0x100000001b3ULL;\nconstexpr uint64_t XN_GOLDEN = 0x9e3779b97f4a7c15ULL;\nconstexpr uint64_t XN_MIX1 = 0xbf58476d1ce4e5b9ULL;\nconstexpr uint64_t XN_MIX2 = 0x94d049bb133111ebULL;\n",
"constexpr uint64_t XN_CFG_HDR = 96;\nconstexpr uint64_t XN_ENTRY = 80;\nconstexpr uint64_t XN_SIG = 64;\n")

t = rep(t, "    uint64_t foff;\n    uint64_t hash;\n};", "    uint64_t foff;\n    uint8_t digest[64];\n};")
t = rep(t, "ranges.push_back({r.addr, r.size, prot, off, 0});", "ranges.push_back({r.addr, r.size, prot, off});")

t = cut(t, "static uint64_t xn_fnv1a(", "    return z ^ (z >> 31);\n}\n\n", "")

t = rep(t, "    const bool is_a64 = ehdr.e_machine == EM_AARCH64;\n",
"    const bool is_a64 = ehdr.e_machine == EM_AARCH64;\n    if (is_a64) xn_fail(\"AArch64 stub is not yet migrated to the signed format\");\n")

t = rep(t, "std::string in_path = argv[2];\n", "std::string in_path = argv[2];\n    const std::string seed_path = argv[3];\n")
t = rep(t, "if (argc < 3 || std::strcmp(argv[1], \"-pso\") != 0) {", "if (argc < 4 || std::strcmp(argv[1], \"-pso\") != 0) {")

t = rep(t, "    const uint64_t stub_hash = xn_fnv1a(stub_s, code_len);\n",
"""    unsigned char stub_digest[64];
    crypto_hash_sha512(stub_digest, stub_s, code_len);
    unsigned char seed[32], sign_pk[32], sign_sk[64];
    {
        FILE *sf = std::fopen(seed_path.c_str(), "rb");
        if (!sf || std::fread(seed, 1, 32, sf) != 32) xn_fail("cannot read 32-byte signing seed");
        std::fclose(sf);
        crypto_sign_seed_keypair(sign_pk, sign_sk, seed);
    }
""")

t = rep(t, "stored_key[i] = kq ^ xn_pad_word(stub_hash, i);",
"""uint64_t dig = 0;
        for (int b = 7; b >= 0; --b)
            dig = (dig << 8) | stub_digest[8 * i + (uint64_t)b];
        stored_key[i] = kq ^ dig;""")

t = rep(t, "r.hash = xn_fnv1a(data.data() + r.foff, r.size);", "crypto_hash_sha512(r.digest, data.data() + r.foff, r.size);")

t = rep(t, "uint64_t config_end = stub_len + entry_bytes;", "uint64_t config_end = stub_len + entry_bytes + XN_SIG;")

t = rep(t, "    uint64_t ent = seg_offset + stub_len;\n",
"""    std::memcpy(data.data() + cfg_base + 64, sign_pk, 32);
    uint64_t ent = seg_offset + stub_len;
""")
t = rep(t, "put64(ent + 16, r.hash);", "std::memcpy(data.data() + ent + 16, r.digest, 64);")

t = rep(t, "    std::memcpy(data.data() + seg_offset + dyn_offset, newdyn.data(), (size_t)dyn_bytes);\n",
"""    {
        const uint64_t manifest_len = XN_CFG_HDR + (uint64_t)ranges.size() * XN_ENTRY;
        uint8_t mdig[64];
        crypto_hash_sha512(mdig, data.data() + cfg_base, manifest_len);
        unsigned long long siglen = 0;
        crypto_sign_detached(data.data() + cfg_base + manifest_len, &siglen, mdig, 64, sign_sk);
    }
    std::memcpy(data.data() + seg_offset + dyn_offset, newdyn.data(), (size_t)dyn_bytes);
""")

open("main.cpp", "w").write(t)
print("written main.cpp, crypto block bytes:", len(crypto))
